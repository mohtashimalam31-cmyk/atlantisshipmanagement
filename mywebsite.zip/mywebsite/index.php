<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];
$contactStatus = in_array($_GET['contact'] ?? '', ['success','invalid','failed'], true) ? $_GET['contact'] : '';
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- ===== SEO ===== -->
    <title>
      Atlantis Ship Management | Maritime Crew Supply in Karachi, Pakistan
    </title>
    <meta
      name="description"
      content="Atlantis Ship Management is a Karachi-based maritime crew supply and ship manning company providing deck officers, engine officers, ratings and specialist crew for tanker, dry bulk, offshore and DP vessels."
    />
    <meta
      name="keywords"
      content="crew supply Karachi, maritime crew Pakistan, ship manning agency, seafarer recruitment, marine manpower, deck officers, engine officers, offshore crew, DP crew, tanker crew"
    />
    <meta name="robots" content="index, follow" />
    <meta name="author" content="Atlantis Ship Management" />
    <meta name="theme-color" content="#071c2b" />
    <link rel="icon" type="image/png" href="atlantis-favicon.png" />
    <link rel="apple-touch-icon" href="apple-touch-icon.png" />
    <link rel="preload" as="image" href="atlantis-emblem.png" />
    <link rel="canonical" href="https://atlantisshipmanagement.com/" />

    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="Atlantis Ship Management" />
    <meta
      property="og:title"
      content="Atlantis Ship Management | Maritime Crew Supply"
    />
    <meta
      property="og:description"
      content="Qualified seafarers for tanker, dry bulk, offshore, DP and specialised vessels. Based in Karachi, Pakistan."
    />
    <meta property="og:url" content="https://atlantisshipmanagement.com/" />
    <meta
      property="og:image"
      content="https://atlantisshipmanagement.com/atlantis-og.png"
    />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:image:alt" content="Atlantis Ship Management logo" />
    <meta name="twitter:card" content="summary_large_image" />

    <!-- ===== Fonts & Libraries ===== -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=DM+Sans:wght@400;500;700&family=Manrope:wght@500;600;700;800&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
      rel="stylesheet"
    />

    <!-- ===== Google structured data (helps Google listing) ===== -->
    <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Atlantis Ship Management",
        "description": "Maritime crew supply and ship manning services based in Karachi, Pakistan.",
        "url": "https://atlantisshipmanagement.com/",
        "telephone": "+92 321 8700807",
        "email": "Badarzaki@gmail.com",
        "image": "https://atlantisshipmanagement.com/atlantis-og.png",
        "logo": "https://atlantisshipmanagement.com/atlantis-full-logo.png",
        "address": {
          "@type": "PostalAddress",
          "streetAddress": "Office No. 823, 7th Floor, Trade Tower, Abdullah Haroon Road, near Metropole Hotel",
          "addressLocality": "Karachi",
          "addressRegion": "Sindh",
          "addressCountry": "PK"
        },
        "areaServed": "Worldwide",
        "serviceType": [
          "Maritime crew supply",
          "Ship manning",
          "Seafarer recruitment"
        ]
      }
    </script>

    <style>
      :root {
        --navy: #071c2b;
        --navy-2: #0d293b;
        --navy-3: #12374a;
        --teal: #159cc8;
        --teal-dark: #107fa3;
        --teal-light: #8dddf2;
        --gold: #e0bb73;
        --cream: #f7f8f6;
        --ink: #172c39;
        --muted: #60717a;
        --line: #dce5e4;
        --heading: "Manrope", sans-serif;
        --body: "DM Sans", sans-serif;
      }
      html {
        scroll-behavior: smooth;
        scroll-padding-top: 85px;
      }
      body {
        font-family: var(--body);
        color: var(--ink);
        overflow-x: hidden;
      }
      h1,
      h2,
      h3,
      h4,
      .brand-name {
        font-family: var(--heading);
        letter-spacing: -0.035em;
      }
      a {
        text-decoration: none;
      }
      ::selection {
        background: var(--teal-light);
        color: var(--navy);
      }
      :focus-visible {
        outline: 3px solid var(--teal);
        outline-offset: 3px;
      }

      /* Top strip */
      .top-strip {
        background: #051522;
        color: #c8d7d9;
        font-size: 0.78rem;
      }
      .top-strip .container {
        min-height: 38px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
      }
      .top-strip i {
        color: var(--teal-light);
        margin-right: 6px;
      }
      .top-strip a {
        color: #c8d7d9;
      }
      .top-strip a:hover {
        color: var(--teal-light);
      }

      /* Header */
      .site-nav {
        background: rgba(5, 20, 33, 0.96);
        backdrop-filter: blur(12px);
        border-bottom: 1px solid rgba(224, 187, 115, 0.16);
        transition: box-shadow 0.3s, background 0.3s;
      }
      .site-nav .navbar {
        min-height: 84px;
        transition: min-height 0.3s;
      }
      .site-nav.scrolled {
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.25);
      }
      .site-nav.scrolled .navbar {
        min-height: 66px;
      }
      .navbar-brand {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 0.25rem 0;
        color: #fff !important;
      }
      .brand-mark {
        display: block;
        width: 66px;
        height: 58px;
        flex: 0 0 auto;
        object-fit: contain;
        border: 0;
        border-radius: 0;
        background: transparent;
        filter: drop-shadow(0 3px 7px rgba(0, 0, 0, 0.24));
        transition: transform 0.3s ease, filter 0.3s ease;
      }
      .navbar-brand:hover .brand-mark {
        transform: translateY(-1px);
        filter: drop-shadow(0 4px 9px rgba(224, 187, 115, 0.2));
      }
      .brand-copy {
        display: block;
        min-width: 0;
      }
      .brand-name {
        display: block;
        color: #f0d08b;
        font-family: "Cinzel", Georgia, serif;
        font-weight: 700;
        font-size: 1.15rem;
        letter-spacing: 0.12em;
        line-height: 1.08;
        white-space: nowrap;
        transition: color 0.25s ease, text-shadow 0.25s ease;
      }
      .navbar-brand:hover .brand-name {
        color: #ffe4a5;
        text-shadow: 0 0 18px rgba(224, 187, 115, 0.15);
      }
      .brand-subtitle {
        display: block;
        color: var(--gold);
        font-size: 0.56rem;
        font-weight: 700;
        letter-spacing: 0.23em;
        text-transform: uppercase;
        margin-top: 6px;
        white-space: nowrap;
      }
      .navbar-toggler {
        border-color: rgba(255, 255, 255, 0.35);
      }
      .navbar-toggler-icon {
        filter: invert(1);
      }
      .nav-link {
        color: #d7e2e4 !important;
        font-weight: 600;
        font-size: 0.88rem;
        padding: 0.6rem 0.85rem !important;
        position: relative;
      }
      .nav-link::after {
        content: "";
        position: absolute;
        left: 0.85rem;
        right: 0.85rem;
        bottom: 0.3rem;
        height: 2px;
        background: var(--teal-light);
        transform: scaleX(0);
        transition: transform 0.25s;
      }
      .nav-link:hover,
      .nav-link.active {
        color: var(--teal-light) !important;
      }
      .nav-link:hover::after,
      .nav-link.active::after {
        transform: scaleX(1);
      }

      /* Buttons */
      .btn-atlantis {
        background: linear-gradient(135deg, var(--teal), var(--teal-dark));
        color: #fff;
        border: 1px solid rgba(224, 187, 115, 0.42);
        border-radius: 6px;
        padding: 0.8rem 1.4rem;
        font-weight: 700;
        font-size: 0.88rem;
        box-shadow: inset 0 1px 0 rgba(255,255,255,0.12);
        transition: all 0.25s;
      }
      .btn-atlantis:hover {
        background: var(--teal-dark);
        border-color: var(--teal-dark);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 12px 24px rgba(8, 57, 63, 0.25);
      }
      .btn-ghost {
        color: #fff;
        border: 1px solid rgba(255, 255, 255, 0.6);
        border-radius: 6px;
        padding: 0.8rem 1.4rem;
        font-weight: 700;
        font-size: 0.88rem;
        transition: all 0.25s;
      }
      .btn-ghost:hover {
        background: #fff;
        color: var(--navy);
        transform: translateY(-2px);
      }

      /* Hero banner (carousel background) */
      .hero {
        position: relative;
        min-height: 680px;
        display: flex;
        align-items: center;
        color: #fff;
        background: var(--navy);
        overflow: hidden;
      }
      .hero .carousel,
      .hero .carousel-inner,
      .hero .carousel-item {
        position: absolute;
        inset: 0;
        height: 100%;
      }
      .hero-slide {
        position: absolute;
        inset: 0;
        background-size: cover;
        background-position: center;
        background-color: var(--navy);
        animation: kenburns 14s ease-out infinite alternate;
      }
      @keyframes kenburns {
        from {
          transform: scale(1);
        }
        to {
          transform: scale(1.12);
        }
      }
      .hero::after {
        content: "";
        position: absolute;
        inset: 0;
        z-index: 1;
        background: linear-gradient(
          90deg,
          rgba(5, 22, 34, 0.96) 0%,
          rgba(7, 28, 43, 0.82) 45%,
          rgba(7, 28, 43, 0.35) 100%
        );
      }
      .hero-content {
        position: relative;
        z-index: 2;
        padding: 100px 0 130px;
      }
      .eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        text-transform: uppercase;
        letter-spacing: 0.22em;
        color: var(--teal);
        font-weight: 800;
        font-size: 0.72rem;
        margin-bottom: 20px;
      }
      .eyebrow::before {
        content: "";
        width: 28px;
        height: 1px;
        background: currentColor;
      }
      .hero .eyebrow {
        color: var(--teal-light);
      }
      .hero h1 {
        font-size: clamp(2.7rem, 6vw, 5.2rem);
        font-weight: 800;
        line-height: 1.06;
        margin-bottom: 24px;
      }
      .hero h1 span {
        color: var(--teal-light);
      }
      .hero-copy {
        color: #d4e0e1;
        font-size: 1.08rem;
        line-height: 1.85;
        max-width: 560px;
        margin-bottom: 32px;
      }
      .hero-trust {
        margin-top: 42px;
        border-left: 2px solid var(--gold);
        padding-left: 16px;
        color: #cbd9dc;
        font-size: 0.85rem;
      }
      .hero-trust i {
        color: var(--gold);
      }
      .hero .carousel-indicators {
        z-index: 3;
        margin-bottom: 2.2rem;
      }
      .hero .carousel-indicators [data-bs-target] {
        width: 34px;
        height: 3px;
        background: var(--teal-light);
      }
      .wave {
        position: absolute;
        bottom: -1px;
        left: 0;
        width: 100%;
        z-index: 2;
        line-height: 0;
      }
      .wave svg {
        width: 100%;
        height: 60px;
      }

      /* Capability bar */
      .value-bar {
        background: var(--navy-2);
        color: #fff;
      }
      .value-item {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 28px 22px;
        border-right: 1px solid rgba(255, 255, 255, 0.08);
        height: 100%;
      }
      .value-icon {
        width: 48px;
        height: 48px;
        flex: 0 0 48px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        border: 1px solid rgba(145, 215, 208, 0.45);
        color: var(--teal-light);
        font-size: 1.2rem;
        transition: all 0.3s;
      }
      .value-item:hover .value-icon {
        background: var(--teal);
        color: #fff;
        transform: rotate(-8deg) scale(1.05);
      }
      .value-item strong {
        display: block;
        font-size: 0.92rem;
      }
      .value-item small {
        color: #aabfc5;
        font-size: 0.78rem;
      }

      /* Sections */
      .section-space {
        padding: 105px 0;
      }
      .section-soft {
        background: var(--cream);
      }
      .section-title {
        font-size: clamp(2rem, 3.8vw, 3.2rem);
        font-weight: 800;
        line-height: 1.15;
        color: var(--navy);
        margin-bottom: 20px;
      }
      .section-copy {
        color: var(--muted);
        line-height: 1.9;
      }
      .section-heading {
        display: flex;
        justify-content: space-between;
        align-items: end;
        gap: 30px;
        margin-bottom: 46px;
      }
      .section-heading > p {
        max-width: 380px;
        color: var(--muted);
        line-height: 1.75;
        margin: 0;
      }

      /* About */
      .image-frame {
        position: relative;
        padding: 0 24px 24px 0;
      }
      .image-frame::after {
        content: "";
        position: absolute;
        left: 24px;
        top: 24px;
        right: 0;
        bottom: 0;
        border: 1px solid var(--teal);
      }
      .image-frame img {
        position: relative;
        z-index: 1;
        width: 100%;
        height: 470px;
        object-fit: cover;
        border-radius: 8px;
        background: var(--navy-2);
      }
      .image-caption {
        position: absolute;
        left: 0;
        bottom: 24px;
        z-index: 2;
        background: var(--navy);
        color: #fff;
        padding: 16px 22px;
        font-size: 0.85rem;
        font-weight: 600;
      }
      .image-caption i {
        color: var(--gold);
        margin-right: 6px;
      }
      .check-list {
        list-style: none;
        padding: 0;
        margin: 26px 0 30px;
      }
      .check-list li {
        padding: 9px 0;
        border-bottom: 1px solid var(--line);
        color: var(--ink);
        font-weight: 500;
      }
      .check-list i {
        color: var(--teal);
        margin-right: 10px;
      }
      .inline-link {
        color: var(--teal-dark);
        font-weight: 700;
      }
      .inline-link i {
        transition: transform 0.25s;
        display: inline-block;
      }
      .inline-link:hover i {
        transform: translateX(5px);
      }

      /* Crew cards */
      .service-card {
        height: 100%;
        background: #fff;
        border: 1px solid var(--line);
        border-radius: 10px;
        padding: 34px 28px;
        position: relative;
        overflow: hidden;
        transition: all 0.3s;
      }
      .service-card::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        height: 3px;
        width: 0;
        background: linear-gradient(90deg, var(--teal), var(--gold));
        transition: width 0.35s;
      }
      .service-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 20px 45px rgba(7, 28, 43, 0.09);
        border-color: #b8d4d0;
      }
      .service-card:hover::before {
        width: 100%;
      }
      .service-icon {
        width: 56px;
        height: 56px;
        border-radius: 12px;
        display: grid;
        place-items: center;
        background: #e5f3f1;
        color: var(--teal-dark);
        font-size: 1.5rem;
        margin-bottom: 24px;
        transition: all 0.3s;
      }
      .service-card:hover .service-icon {
        background: var(--navy);
        color: var(--gold);
      }
      .service-card h3 {
        font-size: 1.35rem;
        font-weight: 800;
        color: var(--navy);
      }
      .service-card p {
        color: var(--muted);
        font-size: 0.92rem;
        line-height: 1.7;
      }
      .rank-list {
        list-style: none;
        padding: 16px 0 0;
        margin: 16px 0 0;
        border-top: 1px solid var(--line);
      }
      .rank-list li {
        padding: 5px 0;
        font-size: 0.9rem;
        color: #415761;
      }
      .rank-list li::before {
        content: "\F285";
        font-family: "bootstrap-icons";
        color: var(--teal);
        font-size: 0.75rem;
        margin-right: 10px;
      }

      /* Vessel cards */
      .industry-card {
        background: var(--navy-2);
        color: #fff;
        height: 100%;
        padding: 34px 30px;
        border: 1px solid rgba(224, 187, 115, 0.14);
        border-radius: 10px;
        position: relative;
        overflow: hidden;
        transition: all 0.3s;
      }
      .industry-card:hover {
        background: var(--navy-3);
        transform: translateY(-5px);
      }
      .industry-card::after {
        content: "";
        position: absolute;
        width: 150px;
        height: 150px;
        border: 1px solid rgba(145, 215, 208, 0.18);
        border-radius: 50%;
        right: -45px;
        bottom: -60px;
        transition: transform 0.5s;
      }
      .industry-card:hover::after {
        transform: scale(1.4);
      }
      .industry-card small {
        color: var(--teal-light);
        font-weight: 700;
        letter-spacing: 0.15em;
        font-size: 0.7rem;
      }
      .industry-card h3 {
        font-size: 1.45rem;
        font-weight: 800;
        margin: 26px 0 6px;
      }
      .industry-card .rank-list {
        border-color: rgba(255, 255, 255, 0.12);
      }
      .industry-card .rank-list li {
        color: #bdcdd1;
      }

      /* Why us */
      .why-box {
        padding: 30px;
        border: 1px solid var(--line);
        border-radius: 10px;
        background: #fff;
        height: 100%;
        transition: all 0.3s;
      }
      .why-box:hover {
        border-color: var(--teal);
        box-shadow: 0 15px 35px rgba(7, 28, 43, 0.07);
      }
      .why-box i {
        font-size: 1.8rem;
        color: var(--teal);
      }
      .why-box h3 {
        font-size: 1.1rem;
        font-weight: 800;
        color: var(--navy);
        margin: 16px 0 10px;
      }
      .why-box p {
        color: var(--muted);
        font-size: 0.9rem;
        line-height: 1.75;
        margin: 0;
      }

      /* Process */
      .process-step {
        border-top: 2px solid var(--line);
        padding-top: 26px;
        position: relative;
        height: 100%;
      }
      .process-step::before {
        content: "";
        position: absolute;
        top: -2px;
        left: 0;
        width: 60px;
        height: 2px;
        background: var(--teal);
      }
      .process-step span {
        display: inline-flex;
        width: 48px;
        height: 48px;
        align-items: center;
        justify-content: center;
        background: var(--navy);
        color: var(--gold);
        font-weight: 800;
        border-radius: 50%;
        margin-bottom: 20px;
        font-family: var(--heading);
      }
      .process-step h3 {
        font-size: 1.1rem;
        font-weight: 800;
        color: var(--navy);
      }
      .process-step p {
        color: var(--muted);
        font-size: 0.9rem;
        line-height: 1.8;
      }

      /* CTA banner */
      .cta-band {
        position: relative;
        color: #fff;
        padding: 90px 0;
        background: var(--navy)
          url("https://images.unsplash.com/photo-1494412574643-ff11b0a5c1c3?auto=format&fit=crop&w=2000&q=80")
          center/cover fixed;
      }
      .cta-band::before {
        content: "";
        position: absolute;
        inset: 0;
        background: linear-gradient(
          90deg,
          rgba(7, 28, 43, 0.94),
          rgba(13, 41, 59, 0.8)
        );
      }
      .cta-band .container {
        position: relative;
      }
      .cta-band h2 {
        font-size: clamp(1.8rem, 3.4vw, 2.8rem);
        font-weight: 800;
      }

      /* FAQ */
      .faq .accordion-item {
        border: 0;
        border-bottom: 1px solid var(--line);
        border-radius: 0;
        background: transparent;
      }
      .faq .accordion-button {
        font-family: var(--heading);
        font-weight: 700;
        color: var(--navy);
        background: transparent;
        padding: 22px 0;
        box-shadow: none;
      }
      .faq .accordion-button:not(.collapsed) {
        color: var(--teal-dark);
      }
      .faq .accordion-body {
        padding: 0 0 22px;
        color: var(--muted);
        line-height: 1.8;
      }

      /* Contact */
      .contact-section {
        background: var(--navy);
        color: #fff;
      }
      .contact-section .section-title {
        color: #fff;
      }
      .contact-section .section-copy {
        color: #c2d2d7;
      }
      .contact-info {
        display: flex;
        gap: 16px;
        align-items: flex-start;
        padding: 18px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      .contact-info i {
        width: 44px;
        height: 44px;
        flex: 0 0 44px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        background: rgba(21, 156, 200, 0.15);
        color: var(--teal-light);
      }
      .contact-info strong {
        display: block;
        font-size: 0.9rem;
      }
      .contact-info span,
      .contact-info a {
        color: #c2d2d7;
        font-size: 0.9rem;
        line-height: 1.7;
      }
      .contact-info a:hover {
        color: var(--teal-light);
      }
      .contact-card {
        background: #fff;
        color: var(--ink);
        padding: clamp(26px, 4vw, 44px);
        border-radius: 10px;
        box-shadow: 0 25px 60px rgba(0, 0, 0, 0.2);
        border-top: 4px solid var(--gold);
      }
      .contact-card h3 {
        font-weight: 800;
        color: var(--navy);
      }
      .form-label {
        font-size: 0.82rem;
        font-weight: 700;
        color: var(--navy);
      }
      .form-control,
      .form-select {
        border-radius: 4px;
        border-color: #d5dfdf;
        padding: 0.8rem 0.95rem;
        font-size: 0.92rem;
      }
      .form-control:focus,
      .form-select:focus {
        border-color: var(--teal);
        box-shadow: 0 0 0 0.2rem rgba(21, 156, 200, 0.15);
      }
      /* Footer */
      .footer {
        background: #051522;
        color: #bdcbd0;
        padding-top: 72px;
      }
      .footer p {
        font-size: 0.9rem;
        line-height: 1.8;
      }
      .footer-heading {
        color: #fff;
        font: 800 0.82rem var(--heading);
        letter-spacing: 0.12em;
        text-transform: uppercase;
        margin-bottom: 20px;
        position: relative;
        padding-bottom: 12px;
      }
      .footer-heading::after {
        content: "";
        position: absolute;
        left: 0;
        bottom: 0;
        width: 30px;
        height: 2px;
        background: var(--gold);
      }
      .footer-links {
        list-style: none;
        padding: 0;
        margin: 0;
      }
      .footer-links li {
        margin-bottom: 11px;
      }
      .footer-links a {
        color: #bdcbd0;
        font-size: 0.9rem;
        transition: all 0.2s;
      }
      .footer-links a:hover {
        color: var(--teal-light);
        padding-left: 5px;
      }
      .footer address {
        font-style: normal;
        font-size: 0.9rem;
        line-height: 1.9;
      }
      .footer address i {
        color: var(--gold);
        margin-right: 8px;
      }
      .footer-bottom {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 50px;
        padding: 22px 0;
        font-size: 0.82rem;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 12px;
      }
      .footer-bottom a {
        color: var(--teal-light);
      }

      .back-to-top {
        position: fixed;
        right: 22px;
        bottom: 22px;
        z-index: 50;
        width: 46px;
        height: 46px;
        border: 0;
        border-radius: 50%;
        background: var(--teal);
        color: #fff;
        font-size: 1.2rem;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
        opacity: 0;
        visibility: hidden;
        transform: translateY(12px);
        transition: all 0.3s;
      }
      .back-to-top.show {
        opacity: 1;
        visibility: visible;
        transform: none;
      }
      .back-to-top:hover {
        background: var(--teal-dark);
      }

      /* Scroll reveal */
      .js .reveal {
        opacity: 0;
        transform: translateY(28px);
        transition:
          opacity 0.7s ease,
          transform 0.7s ease;
      }
      .js .reveal.visible {
        opacity: 1;
        transform: none;
      }
      .js .reveal.d1 {
        transition-delay: 0.1s;
      }
      .js .reveal.d2 {
        transition-delay: 0.2s;
      }
      .js .reveal.d3 {
        transition-delay: 0.3s;
      }

      @media (max-width: 991.98px) {
        .section-space {
          padding: 78px 0;
        }
        .section-heading {
          display: block;
        }
        .section-heading > p {
          margin-top: 16px;
        }
        .navbar-collapse {
          padding: 10px 0 18px;
        }
        .nav-link::after {
          display: none;
        }
        .value-item {
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }
        .cta-band {
          background-attachment: scroll;
        }
      }
      @media (max-width: 575.98px) {
        .top-strip .hide-sm {
          display: none;
        }
        .navbar-brand {
          gap: 7px;
        }
        .brand-name {
          font-size: 0.88rem;
          letter-spacing: 0.08em;
        }
        .brand-subtitle {
          font-size: 0.49rem;
          letter-spacing: 0.16em;
          margin-top: 5px;
        }
        .brand-mark {
          width: 48px;
          height: 44px;
        }
        .hero {
          min-height: 620px;
        }
        .hero-content {
          padding: 70px 0 110px;
        }
        .hero-actions a {
          width: 100%;
          text-align: center;
        }
        .image-frame img {
          height: 340px;
        }
      }
      @media (prefers-reduced-motion: reduce) {
        * {
          animation: none !important;
          transition: none !important;
        }
        .js .reveal {
          opacity: 1;
          transform: none;
        }
      }
    </style>
  </head>

  <body
    data-bs-spy="scroll"
    data-bs-target="#mainNav"
    data-bs-offset="100"
    tabindex="0"
  >
    <a
      href="#main-content"
      class="visually-hidden-focusable position-absolute top-0 start-0 bg-white p-2 z-3"
      >Skip to content</a
    >

    <!-- Top strip -->
    <div class="top-strip">
      <div class="container">
        <span
          ><i class="bi bi-geo-alt"></i>Karachi, Pakistan &middot; Serving
          maritime employers worldwide</span
        >
        <span class="hide-sm">
          <a href="mailto:Badarzaki@gmail.com"
            ><i class="bi bi-envelope"></i>Badarzaki@gmail.com</a
          >
          &nbsp;&nbsp;
          <a href="tel:+923218700807"
            ><i class="bi bi-telephone"></i>+92 321 8700807</a
          >
        </span>
      </div>
    </div>

    <!-- Header -->
    <header class="site-nav sticky-top" id="siteNav">
      <nav class="navbar navbar-expand-lg" aria-label="Main navigation">
        <div class="container">
          <a
            class="navbar-brand"
            href="#home"
            aria-label="Atlantis Ship Management home"
          >
            <img class="brand-mark" src="atlantis-emblem.png" alt="" aria-hidden="true" width="715" height="586" />
            <span class="brand-copy">
              <span class="brand-name">ATLANTIS</span>
              <span class="brand-subtitle">SHIP MANAGEMENT</span>
            </span>
          </a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#mainNav"
            aria-controls="mainNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto align-items-lg-center">
              <li class="nav-item">
                <a class="nav-link" href="#home">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#about">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#services">Crew Supply</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#vessels">Industries</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#why">Why Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">Contact</a>
              </li>
              <li class="nav-item ms-lg-3 mt-2 mt-lg-0">
                <a class="btn btn-atlantis" href="#contact"
                  >Request Crew <i class="bi bi-arrow-right ms-1"></i
                ></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <main id="main-content">
      <!-- HERO BANNER -->
      <section class="hero" id="home" aria-labelledby="hero-title">
        <div
          id="heroCarousel"
          class="carousel slide carousel-fade"
          data-bs-ride="carousel"
          data-bs-interval="6000"
          data-bs-pause="false"
        >
          <div class="carousel-indicators">
            <button
              type="button"
              data-bs-target="#heroCarousel"
              data-bs-slide-to="0"
              class="active"
              aria-current="true"
              aria-label="Slide 1"
            ></button>
            <button
              type="button"
              data-bs-target="#heroCarousel"
              data-bs-slide-to="1"
              aria-label="Slide 2"
            ></button>
            <button
              type="button"
              data-bs-target="#heroCarousel"
              data-bs-slide-to="2"
              aria-label="Slide 3"
            ></button>
          </div>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div
                class="hero-slide"
                style="
                  background-image: url(&quot;https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=2000&q=80&quot;);
                "
              ></div>
            </div>
            <div class="carousel-item">
              <div
                class="hero-slide"
                style="
                  background-image: url(&quot;https://images.unsplash.com/photo-1494412574643-ff11b0a5c1c3?auto=format&fit=crop&w=2000&q=80&quot;);
                "
              ></div>
            </div>
            <div class="carousel-item">
              <div
                class="hero-slide"
                style="
                  background-image: url(&quot;https://images.unsplash.com/photo-1605745341112-85968b19335b?auto=format&fit=crop&w=2000&q=80&quot;);
                "
              ></div>
            </div>
          </div>
        </div>

        <div class="container hero-content">
          <div class="eyebrow">Your Crew. Our Commitment.</div>
          <h1 id="hero-title">
            Trusted Maritime Crew.<br /><span>Explore Without Limits.</span>
          </h1>
          <p class="hero-copy">
            Professional crew supply and manning support for tanker, dry bulk,
            offshore, DP and specialised vessels &mdash; from our office in
            Karachi to fleets around the world.
          </p>
          <div class="hero-actions d-flex flex-wrap gap-3">
            <a class="btn btn-atlantis" href="#contact"
              >Request Crew <i class="bi bi-arrow-right ms-1"></i
            ></a>
            <a class="btn btn-ghost" href="#services">Explore Crew Supply</a>
          </div>
          <div class="hero-trust">
            <i class="bi bi-shield-check me-2"></i>Qualified
            &nbsp;&middot;&nbsp; Document-ready &nbsp;&middot;&nbsp; Experienced
            &nbsp;&middot;&nbsp; International crew supply
          </div>
        </div>

        <div class="wave" aria-hidden="true">
          <svg viewBox="0 0 1440 60" preserveAspectRatio="none">
            <path
              fill="#0d293b"
              d="M0,32 C240,64 480,0 720,24 C960,48 1200,8 1440,30 L1440,60 L0,60 Z"
            />
          </svg>
        </div>
      </section>

      <!-- CAPABILITY BAR -->
      <section class="value-bar" aria-label="Our priorities">
        <div class="container">
          <div class="row g-0">
            <div class="col-6 col-lg-3">
              <div class="value-item">
                <span class="value-icon"
                  ><i class="bi bi-person-check"></i
                ></span>
                <div>
                  <strong>Qualified Seafarers</strong
                  ><small>Matched to rank &amp; vessel</small>
                </div>
              </div>
            </div>
            <div class="col-6 col-lg-3">
              <div class="value-item">
                <span class="value-icon"
                  ><i class="bi bi-file-earmark-check"></i
                ></span>
                <div>
                  <strong>Document-Ready</strong
                  ><small>Certificates reviewed</small>
                </div>
              </div>
            </div>
            <div class="col-6 col-lg-3">
              <div class="value-item">
                <span class="value-icon"><i class="bi bi-globe2"></i></span>
                <div>
                  <strong>Worldwide Supply</strong
                  ><small>International operations</small>
                </div>
              </div>
            </div>
            <div class="col-6 col-lg-3">
              <div class="value-item">
                <span class="value-icon"><i class="bi bi-headset"></i></span>
                <div>
                  <strong>Responsive Support</strong
                  ><small>From enquiry to joining</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- ABOUT -->
      <section class="section-space" id="about" aria-labelledby="about-title">
        <div class="container">
          <div class="row align-items-center g-5">
            <div class="col-lg-6 reveal">
              <div class="image-frame">
                <img
                  src="https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=1200&q=80"
                  alt="Open sea and maritime environment"
                  width="1200"
                  height="900"
                  loading="lazy"
                />
                <div class="image-caption">
                  <i class="bi bi-geo-alt-fill"></i>Karachi, Pakistan. Connected
                  to the maritime world.
                </div>
              </div>
            </div>
            <div class="col-lg-6 reveal d1">
              <div class="eyebrow">Your Maritime Manpower Partner</div>
              <h2 class="section-title" id="about-title">
                The right people.<br />For the journey ahead.
              </h2>
              <p class="section-copy">
                Atlantis Ship Management supports shipowners, vessel operators
                and ship managers with qualified seafarers. From our Karachi
                office, we focus on experienced, properly documented crew
                matched to each vessel's needs.
              </p>
              <p class="section-copy">
                We work with your crewing and technical teams to understand the
                vessel, the rank and the joining schedule, then put forward
                suitable candidates for your review.
              </p>
              <ul class="check-list">
                <li>
                  <i class="bi bi-check-circle-fill"></i>Candidates screened
                  against rank and vessel type
                </li>
                <li>
                  <i class="bi bi-check-circle-fill"></i>Certificates and
                  documentation reviewed before proposal
                </li>
                <li>
                  <i class="bi bi-check-circle-fill"></i>Clear, timely
                  communication throughout
                </li>
              </ul>
              <a class="inline-link" href="#contact"
                >Discuss your requirement <i class="bi bi-arrow-right"></i
              ></a>
            </div>
          </div>
        </div>
      </section>

      <!-- CREW SUPPLY -->
      <section
        class="section-space section-soft"
        id="services"
        aria-labelledby="services-title"
      >
        <div class="container">
          <div class="section-heading reveal">
            <div>
              <div class="eyebrow">Crew Supply &amp; Manning</div>
              <h2 class="section-title mb-0" id="services-title">
                Qualified crew.<br />Across every rank.
              </h2>
            </div>
            <p>
              From deck and engine officers to ratings and specialist personnel,
              aligned with your operational needs. Availability is confirmed for
              each enquiry.
            </p>
          </div>
          <div class="row g-4">
            <div class="col-md-6 col-xl-3 reveal">
              <article class="service-card">
                <div class="service-icon"><i class="bi bi-compass"></i></div>
                <h3>Deck Officers</h3>
                <p>Experienced leadership and safe navigation.</p>
                <ul class="rank-list">
                  <li>Master</li>
                  <li>Chief Officer</li>
                  <li>Second Officer</li>
                  <li>Third Officer</li>
                </ul>
              </article>
            </div>
            <div class="col-md-6 col-xl-3 reveal d1">
              <article class="service-card">
                <div class="service-icon">
                  <i class="bi bi-gear-wide-connected"></i>
                </div>
                <h3>Engine Officers</h3>
                <p>Technical skill and operational readiness.</p>
                <ul class="rank-list">
                  <li>Chief Engineer</li>
                  <li>Second Engineer</li>
                  <li>Third Engineer</li>
                  <li>Fourth Engineer</li>
                </ul>
              </article>
            </div>
            <div class="col-md-6 col-xl-3 reveal d2">
              <article class="service-card">
                <div class="service-icon"><i class="bi bi-people"></i></div>
                <h3>Ratings</h3>
                <p>Dependable people for essential operations.</p>
                <ul class="rank-list">
                  <li>Bosun &amp; AB</li>
                  <li>OS &amp; Oiler</li>
                  <li>Fitter &amp; Motorman</li>
                  <li>Wiper &amp; Pumpman</li>
                  <li>Electrician</li>
                </ul>
              </article>
            </div>
            <div class="col-md-6 col-xl-3 reveal d3">
              <article class="service-card">
                <div class="service-icon">
                  <i class="bi bi-life-preserver"></i>
                </div>
                <h3>Specialist Personnel</h3>
                <p>The right experience for complex vessels.</p>
                <ul class="rank-list">
                  <li>DP-experienced crew</li>
                  <li>Offshore crew</li>
                  <li>Drilling vessel personnel</li>
                  <li>Tanker-experienced crew</li>
                </ul>
              </article>
            </div>
          </div>
          <div class="text-center mt-5 reveal">
            <a class="btn btn-atlantis" href="#contact"
              >Tell Us Your Manning Requirement
              <i class="bi bi-arrow-right ms-1"></i
            ></a>
          </div>
        </div>
      </section>

      <!-- VESSELS / INDUSTRIES -->
      <section
        class="section-space"
        id="vessels"
        aria-labelledby="vessels-title"
      >
        <div class="container">
          <div class="section-heading reveal">
            <div>
              <div class="eyebrow">Vessels &amp; Industries</div>
              <h2 class="section-title mb-0" id="vessels-title">
                Built around your vessel.
              </h2>
            </div>
            <p>
              Vessel-specific crew supply for commercial shipping, offshore
              operations and specialised maritime units.
            </p>
          </div>
          <div class="row g-4">
            <div class="col-sm-6 col-lg-3 reveal">
              <article class="industry-card">
                <small>01 / CATEGORY</small>
                <h3>Tankers</h3>
                <ul class="rank-list">
                  <li>Crude Oil Tankers</li>
                  <li>Product Tankers</li>
                  <li>Chemical Tankers</li>
                  <li>LNG / LPG Carriers</li>
                </ul>
              </article>
            </div>
            <div class="col-sm-6 col-lg-3 reveal d1">
              <article class="industry-card">
                <small>02 / CATEGORY</small>
                <h3>Dry Bulk</h3>
                <ul class="rank-list">
                  <li>Handysize</li>
                  <li>Supramax</li>
                  <li>Panamax</li>
                  <li>Capesize</li>
                </ul>
              </article>
            </div>
            <div class="col-sm-6 col-lg-3 reveal d2">
              <article class="industry-card">
                <small>03 / CATEGORY</small>
                <h3>Offshore</h3>
                <ul class="rank-list">
                  <li>Offshore Supply Vessels</li>
                  <li>Platform Supply Vessels</li>
                  <li>AHTS</li>
                  <li>Diving Support Vessels</li>
                </ul>
              </article>
            </div>
            <div class="col-sm-6 col-lg-3 reveal d3">
              <article class="industry-card">
                <small>04 / CATEGORY</small>
                <h3>DP &amp; Specialised</h3>
                <ul class="rank-list">
                  <li>DP1 / DP2 / DP3</li>
                  <li>Survey Vessels</li>
                  <li>Drilling Vessels</li>
                  <li>Specialised Offshore Units</li>
                </ul>
              </article>
            </div>
          </div>
          <p class="small text-secondary mt-4 mb-0">
            Candidate suitability, specialist qualifications and availability
            are confirmed for each requirement.
          </p>
        </div>
      </section>

      <!-- WHY US -->
      <section
        class="section-space section-soft"
        id="why"
        aria-labelledby="why-title"
      >
        <div class="container">
          <div class="text-center mb-5 reveal">
            <div class="eyebrow justify-content-center">Why Atlantis</div>
            <h2 class="section-title" id="why-title">
              A crewing partner you can rely on.
            </h2>
          </div>
          <div class="row g-4">
            <div class="col-md-6 col-lg-3 reveal">
              <div class="why-box">
                <i class="bi bi-search"></i>
                <h3>Careful Selection</h3>
                <p>
                  Every candidate is considered against the rank, vessel type
                  and operating profile.
                </p>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 reveal d1">
              <div class="why-box">
                <i class="bi bi-patch-check"></i>
                <h3>Document Focus</h3>
                <p>
                  Certificates, endorsements and travel documents are reviewed
                  before proposal.
                </p>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 reveal d2">
              <div class="why-box">
                <i class="bi bi-lightning-charge"></i>
                <h3>Prompt Response</h3>
                <p>
                  We understand vessel schedules and reply to requirements
                  without delay.
                </p>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 reveal d3">
              <div class="why-box">
                <i class="bi bi-chat-dots"></i>
                <h3>Clear Communication</h3>
                <p>
                  Straightforward updates from first enquiry to crew joining.
                </p>
              </div>
            </div>
          </div>

          <!-- Process -->
          <div class="row g-4 mt-5 pt-3" id="process">
            <div class="col-md-4 reveal">
              <div class="process-step">
                <span>01</span>
                <h3>Share the details</h3>
                <p>
                  Vessel type, rank, joining port, date, contract length and
                  required certificates.
                </p>
              </div>
            </div>
            <div class="col-md-4 reveal d1">
              <div class="process-step">
                <span>02</span>
                <h3>Review the candidates</h3>
                <p>
                  We propose suitable profiles with experience, documents and
                  availability.
                </p>
              </div>
            </div>
            <div class="col-md-4 reveal d2">
              <div class="process-step">
                <span>03</span>
                <h3>Crew joins the vessel</h3>
                <p>
                  We agree on next steps and support the joining arrangements.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- CTA BANNER -->
      <section class="cta-band">
        <div class="container">
          <div class="row align-items-center g-4">
            <div class="col-lg-8 reveal">
              <div class="eyebrow" style="color: var(--teal-light)">
                Need crew urgently?
              </div>
              <h2>
                Tell us the rank and joining date &mdash; we'll take it from
                there.
              </h2>
            </div>
            <div class="col-lg-4 text-lg-end reveal d1">
              <a class="btn btn-atlantis btn-lg" href="#contact"
                >Request Crew Now <i class="bi bi-arrow-right ms-1"></i
              ></a>
            </div>
          </div>
        </div>
      </section>

      <!-- FAQ -->
      <section class="section-space faq" aria-labelledby="faq-title">
        <div class="container">
          <div class="row g-5">
            <div class="col-lg-5 reveal">
              <div class="eyebrow">Helpful Information</div>
              <h2 class="section-title" id="faq-title">
                Before you get in touch.
              </h2>
              <p class="section-copy">
                A few details make your crew enquiry faster and more useful.
              </p>
            </div>
            <div class="col-lg-7 reveal d1">
              <div class="accordion" id="crewFaq">
                <div class="accordion-item">
                  <h3 class="accordion-header">
                    <button
                      class="accordion-button"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#faq1"
                      aria-expanded="true"
                    >
                      What should I include in a crew enquiry?
                    </button>
                  </h3>
                  <div
                    id="faq1"
                    class="accordion-collapse collapse show"
                    data-bs-parent="#crewFaq"
                  >
                    <div class="accordion-body">
                      Rank, vessel type, joining port and date, contract length,
                      required certificates and any specialist experience (e.g.
                      DP or tanker endorsements).
                    </div>
                  </div>
                </div>
                <div class="accordion-item">
                  <h3 class="accordion-header">
                    <button
                      class="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#faq2"
                    >
                      Which vessel types do you supply crew for?
                    </button>
                  </h3>
                  <div
                    id="faq2"
                    class="accordion-collapse collapse"
                    data-bs-parent="#crewFaq"
                  >
                    <div class="accordion-body">
                      Tankers, dry bulk carriers, offshore support vessels, DP
                      vessels and other specialised units.
                    </div>
                  </div>
                </div>
                <div class="accordion-item">
                  <h3 class="accordion-header">
                    <button
                      class="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#faq3"
                    >
                      Are specialist candidates always available?
                    </button>
                  </h3>
                  <div
                    id="faq3"
                    class="accordion-collapse collapse"
                    data-bs-parent="#crewFaq"
                  >
                    <div class="accordion-body">
                      Availability and suitability are confirmed for each
                      specific requirement.
                    </div>
                  </div>
                </div>
                <div class="accordion-item">
                  <h3 class="accordion-header">
                    <button
                      class="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#faq4"
                    >
                      Where is your office?
                    </button>
                  </h3>
                  <div
                    id="faq4"
                    class="accordion-collapse collapse"
                    data-bs-parent="#crewFaq"
                  >
                    <div class="accordion-body">
                      Office No. 823, 7th Floor, Trade Tower, Abdullah Haroon
                      Road, near Metropole Hotel, Karachi, Pakistan.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- CONTACT -->
      <section
        class="section-space contact-section"
        id="contact"
        aria-labelledby="contact-title"
      >
        <div class="container">
          <div class="row g-5">
            <div class="col-lg-5 reveal">
              <div class="eyebrow" style="color: var(--teal-light)">
                Get in Touch
              </div>
              <h2 class="section-title" id="contact-title">
                Let's talk about your next crew requirement.
              </h2>
              <p class="section-copy">
                Send us the essentials and we'll respond with a practical next
                step.
              </p>

              <div class="contact-info">
                <i class="bi bi-geo-alt"></i>
                <div>
                  <strong>Office Address</strong
                  ><span
                    >Office No. 823, 7th Floor, Trade Tower,<br />Abdullah
                    Haroon Road, Near Metropole Hotel,<br />Karachi,
                    Pakistan</span
                  >
                </div>
              </div>
              <div class="contact-info">
                <i class="bi bi-envelope"></i>
                <div>
                  <strong>Email</strong
                  ><a href="mailto:Badarzaki@gmail.com"
                    >Badarzaki@gmail.com</a
                  >
                </div>
              </div>
              <div class="contact-info">
                <i class="bi bi-telephone"></i>
                <div>
                  <strong>Phone / WhatsApp</strong
                  ><a href="tel:+923218700807">+92 321 8700807</a>
                </div>
              </div>

            </div>

            <div class="col-lg-7 reveal d1">
              <div class="contact-card">
                <h3>Send a Crew Enquiry</h3>
                <p class="text-secondary small mb-4">
                  Your enquiry is sent directly to our team. Please do not include passport or bank details.
                </p>
                <form id="enquiryForm" class="needs-validation" action="contact.php" method="post" novalidate>
                  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>" />
                  <div class="visually-hidden" aria-hidden="true"><label>Leave this field empty <input type="text" name="website" tabindex="-1" autocomplete="off" /></label></div>
                  <div class="row g-3">
                    <div class="col-md-6">
                      <label class="form-label" for="fullName"
                        >Your name *</label
                      >
                      <input
                        class="form-control"
                        id="fullName" name="name"
                        required
                        maxlength="100"
                        autocomplete="name"
                      />
                      <div class="invalid-feedback">
                        Please enter your name.
                      </div>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label" for="company">Company</label>
                      <input
                        class="form-control"
                        id="company" name="company"
                        maxlength="120"
                        autocomplete="organization"
                      />
                    </div>
                    <div class="col-md-6">
                      <label class="form-label" for="email"
                        >Email address *</label
                      >
                      <input
                        class="form-control"
                        id="email" name="email"
                        type="email"
                        required
                        maxlength="150"
                        autocomplete="email"
                      />
                      <div class="invalid-feedback">
                        Please enter a valid email.
                      </div>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label" for="vessel">Vessel type</label>
                      <select class="form-select" id="vessel" name="vessel">
                        <option value="">Select vessel type</option>
                        <option>Tanker</option>
                        <option>Dry bulk</option>
                        <option>Offshore</option>
                        <option>DP / specialised</option>
                        <option>Other</option>
                      </select>
                    </div>
                    <div class="col-12">
                      <label class="form-label" for="message"
                        >Crew requirement *</label
                      >
                      <textarea
                        class="form-control"
                        id="message" name="message"
                        rows="5"
                        required
                        maxlength="3000"
                        placeholder="Rank, certificates, joining port and expected date..."
                      ></textarea>
                      <div class="invalid-feedback">
                        Please describe your requirement.
                      </div>
                    </div>
                    <div class="col-12">
                      <button class="btn btn-atlantis w-100" type="submit" id="sendBtn">
                        Send Enquiry <i class="bi bi-send ms-1"></i>
                      </button>
                      <p class="small text-secondary mt-3 mb-0">
                        By sending, you agree to our
                        <a class="inline-link" href="privacy.php">Privacy Policy</a>.
                      </p>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>

    <!-- FOOTER -->
    <footer class="footer">
      <div class="container">
        <div class="row g-5">
          <div class="col-lg-4">
            <a class="navbar-brand mb-3" href="#home" aria-label="Atlantis Ship Management home">
              <img class="brand-mark" src="atlantis-emblem.png" alt="" aria-hidden="true" width="715" height="586" />
              <span class="brand-copy">
                <span class="brand-name">ATLANTIS</span>
                <span class="brand-subtitle">SHIP MANAGEMENT</span>
              </span>
            </a>
            <p class="mt-3">
              Tanker &middot; Dry Bulk &middot; Offshore &middot; DP &middot;
              Specialised Vessels.<br />Based in Karachi. Focused on your vessel
              requirements.
            </p>
          </div>
          <div class="col-6 col-lg-2">
            <h2 class="footer-heading">Explore</h2>
            <ul class="footer-links">
              <li><a href="#about">About Us</a></li>
              <li><a href="#services">Crew Supply</a></li>
              <li><a href="#vessels">Industries</a></li>
              <li><a href="#why">Why Us</a></li>
            </ul>
          </div>
          <div class="col-6 col-lg-2">
            <h2 class="footer-heading">Crew</h2>
            <ul class="footer-links">
              <li><a href="#services">Deck Officers</a></li>
              <li><a href="#services">Engine Officers</a></li>
              <li><a href="#services">Ratings</a></li>
              <li><a href="#services">Specialist Crew</a></li>
            </ul>
          </div>
          <div class="col-lg-4">
            <h2 class="footer-heading">Karachi Office</h2>
            <address>
              <i class="bi bi-geo-alt-fill"></i>Office No. 823, 8th Floor, Trade
              Tower,<br />
              <span class="ms-4"
                >Abdullah Haroon Road, Near Metropole Hotel,</span
              ><br />
              <span class="ms-4">Karachi, Pakistan</span><br />
              <i class="bi bi-envelope-fill"></i
              ><a class="text-reset" href="mailto:Badarzaki@gmail.com"
                >Badarzaki@gmail.com</a
              ><br />
              <i class="bi bi-telephone-fill"></i
              ><a class="text-reset" href="tel:+923218700807">+92 321 8700807</a>
            </address>
          </div>
        </div>
        <div class="footer-bottom">
          <span
            >&copy; <span id="year"></span> Atlantis Ship Management. All rights
            reserved.</span
          >
          <span><a href="privacy.php">Privacy Policy</a> &nbsp;&middot;&nbsp; <a href="#home">Back to top <i class="bi bi-arrow-up"></i></a></span>
        </div>
      </div>
    </footer>

    <button
      class="back-to-top"
      id="backToTop"
      type="button"
      aria-label="Back to top"
      data-bs-toggle="tooltip"
      data-bs-placement="left"
      data-bs-title="Back to top"
    >
      <i class="bi bi-arrow-up"></i>
    </button>

    <!-- Toast for form messages -->
    <div class="toast-container position-fixed bottom-0 start-0 p-3">
      <div
        id="formToast"
        class="toast align-items-center text-bg-dark border-0"
        role="status"
        aria-live="polite"
        aria-atomic="true"
      >
        <div class="d-flex">
          <div class="toast-body" id="toastMsg"></div>
          <button
            type="button"
            class="btn-close btn-close-white me-2 m-auto"
            data-bs-dismiss="toast"
            aria-label="Close"
          ></button>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      const CONTACT_STATUS = <?= json_encode($contactStatus) ?>;

      document.getElementById("year").textContent = new Date().getFullYear();

      // Tooltips
      document
        .querySelectorAll('[data-bs-toggle="tooltip"]')
        .forEach((el) => new bootstrap.Tooltip(el));

      // Header shrink + back-to-top
      const nav = document.getElementById("siteNav"),
        topBtn = document.getElementById("backToTop");
      const onScroll = () => {
        nav.classList.toggle("scrolled", scrollY > 40);
        topBtn.classList.toggle("show", scrollY > 500);
      };
      addEventListener("scroll", onScroll, { passive: true });
      onScroll();
      topBtn.addEventListener("click", () =>
        scrollTo({ top: 0, behavior: "smooth" }),
      );

      // Scroll reveal animation
      if (
        !matchMedia("(prefers-reduced-motion: reduce)").matches &&
        "IntersectionObserver" in window
      ) {
        document.body.classList.add("js");
        const io = new IntersectionObserver(
          (entries) =>
            entries.forEach((e) => {
              if (e.isIntersecting) {
                e.target.classList.add("visible");
                io.unobserve(e.target);
              }
            }),
          { threshold: 0.1 },
        );
        document.querySelectorAll(".reveal").forEach((el) => io.observe(el));
      }

      // Close mobile menu after clicking a link
      document.querySelectorAll("#mainNav a").forEach((a) =>
        a.addEventListener("click", () => {
          const menu = document.getElementById("mainNav");
          if (menu.classList.contains("show"))
            bootstrap.Collapse.getOrCreateInstance(menu).hide();
        }),
      );

      // Enquiry form with Bootstrap validation + toast
      const toast = new bootstrap.Toast(document.getElementById("formToast"));
      const showToast = (msg) => {
        document.getElementById("toastMsg").textContent = msg;
        toast.show();
      };

      // Enquiry form: validate in browser, then post to contact.php
      const form = document.getElementById("enquiryForm");
      form.addEventListener("submit", (e) => {
        if (!form.checkValidity()) {
          e.preventDefault();
          form.classList.add("was-validated");
          return;
        }
        const btn = document.getElementById("sendBtn");
        btn.disabled = true;
        btn.textContent = "Sending...";
      });

      // Result message after contact.php redirects back
      const messages = {
        success: "Thank you. Your enquiry has been sent. We will reply shortly.",
        invalid: "Please complete all required fields with a valid email and try again.",
        failed: "We could not send your enquiry. Please email or call us directly.",
      };
      if (messages[CONTACT_STATUS]) {
        showToast(messages[CONTACT_STATUS]);
        if (history.replaceState)
          history.replaceState(null, "", location.pathname + "#contact");
      }
    </script>
  </body>
</html>
