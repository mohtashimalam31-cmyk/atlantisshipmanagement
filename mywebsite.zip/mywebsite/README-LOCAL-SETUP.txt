ATLANTIS SHIP MANAGEMENT — XAMPP PACKAGE

LOCAL SETUP (Windows + XAMPP)
1. Close/open the XAMPP Control Panel and click Start for Apache.
2. Extract this ZIP into C:\xampp\htdocs\. It will create C:\xampp\htdocs\mywebsite\.
3. Confirm that C:\xampp\htdocs\mywebsite\index.php exists.
4. Open http://localhost/mywebsite/ in your browser.
5. If you still see a folder listing, confirm you extracted the ZIP and that index.php is directly inside the mywebsite folder (not inside another nested folder).

PHP COMPATIBILITY
The contact form handler has been adjusted to avoid PHP 8.1-only `never` syntax, so it can be parsed by the PHP 8.0.30 version shown in the screenshot.

CONTACT FORM EMAIL
On a local XAMPP installation, PHP mail() may not send email until SMTP is configured. If the site displays but form submission says it could not send, configure SMTP or test on PHP hosting with mail/SMTP enabled.

NOTES
- Use index.php as the homepage. The older index.html draft was intentionally left out because it contains placeholder phone/email details and a different form handler.
- The Google verification file is a placeholder; replace it with the actual file downloaded from Google Search Console before using it for verification.
- Keep SSL redirects disabled locally; enable them only after HTTPS/SSL is active on the live domain.
