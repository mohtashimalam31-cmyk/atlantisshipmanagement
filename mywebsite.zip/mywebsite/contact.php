<?php
declare(strict_types=1);
session_start();

function redirectWithStatus(string $status): void {
    header('Location: index.php?contact=' . rawurlencode($status) . '#contact', true, 303);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}
if (!empty($_POST['website'] ?? '')) {
    redirectWithStatus('success');
}
$token = (string)($_POST['csrf_token'] ?? '');
if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
    redirectWithStatus('invalid');
}

function clean(string $value, int $limit): string {
    $value = trim(strip_tags($value));
    return mb_substr($value, 0, $limit, 'UTF-8');
}

$name = clean((string)($_POST['name'] ?? ''), 100);
$company = clean((string)($_POST['company'] ?? ''), 120);
$email = filter_var(trim((string)($_POST['email'] ?? '')), FILTER_VALIDATE_EMAIL);
$vessel = clean((string)($_POST['vessel'] ?? ''), 80);
$message = clean((string)($_POST['message'] ?? ''), 3000);

if ($name === '' || !$email || $message === '') {
    redirectWithStatus('invalid');
}

$recipient = 'Badarzaki@gmail.com';
$subject = 'Website crew enquiry from ' . $name;
$body = "New crew enquiry from Atlantis Ship Management website.\n\n"
      . "Name: {$name}\n"
      . "Company: " . ($company ?: 'Not provided') . "\n"
      . "Email: {$email}\n"
      . "Vessel type: " . ($vessel ?: 'Not provided') . "\n\n"
      . "Requirement:\n{$message}\n";
$headers = [
    'From: Atlantis Ship Management Website <no-reply@atlantisshipmanagement.com>',
    'Reply-To: ' . $email,
    'Content-Type: text/plain; charset=UTF-8',
    'X-Content-Type-Options: nosniff',
];

$sent = mail($recipient, $subject, $body, implode("\r\n", $headers));
redirectWithStatus($sent ? 'success' : 'failed');
