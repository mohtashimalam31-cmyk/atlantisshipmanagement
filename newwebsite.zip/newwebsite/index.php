<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$user = current_user();
if (!$user) redirect('login.php');
redirect($user['role'] === 'crew' ? 'crew_portal.php' : 'dashboard.php');
