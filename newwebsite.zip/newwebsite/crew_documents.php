<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$user=require_login(['admin','employee']); $pdo=db(); $errors=[];
$allowedTypes=['pdf'=>['application/pdf'],'png'=>['image/png'],'jpg'=>['image/jpeg'],'jpeg'=>['image/jpeg'],'doc'=>['application/msword'],'docx'=>['application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/zip']];
$uploadDir=app_config()['uploads_dir'];
if (!is_dir($uploadDir) && !mkdir($uploadDir,0750,true) && !is_dir($uploadDir)) $errors[]='Upload storage is not available. Ask your hosting administrator to check directory permissions.';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf(); $action=(string)($_POST['action']??'upload'); $id=(int)($_POST['id']??0);
    if ($action==='delete') {
        if (!is_admin()) { http_response_code(403); exit('Only an administrator can delete documents.'); }
        $stmt=$pdo->prepare('SELECT stored_name FROM crew_documents WHERE id=?'); $stmt->execute([$id]); $doc=$stmt->fetch();
        if ($doc) { $path=$uploadDir.'/'.$doc['stored_name']; if (is_file($path)) @unlink($path); $pdo->prepare('DELETE FROM crew_documents WHERE id=?')->execute([$id]); log_activity('delete','crew_document',$id,'Deleted crew document'); flash('success','Document deleted.'); }
        redirect('crew_documents.php');
    }
    if ($action==='upload' && !$errors) {
        $crewId=(int)($_POST['crew_id']??0); $docType=trim((string)($_POST['document_type']??'')); $expiry=trim((string)($_POST['expiry_date']??''));
        $stmt=$pdo->prepare('SELECT id FROM crew_members WHERE id=?'); $stmt->execute([$crewId]);
        if (!$stmt->fetchColumn()) $errors[]='Select a valid crew member.';
        if ($docType==='') $errors[]='Document type is required.';
        if ($expiry!=='' && !preg_match('/^\d{4}-\d{2}-\d{2}$/',$expiry)) $errors[]='Enter a valid expiry date.';
        $file=$_FILES['document']??null;
        if (!$file || !isset($file['error']) || $file['error']!==UPLOAD_ERR_OK) $errors[]='Choose a document file that uploads successfully.';
        if ($file && isset($file['size']) && $file['size']>app_config()['max_upload_bytes']) $errors[]='File is larger than the 5 MB limit.';
        if ($file && isset($file['tmp_name']) && is_uploaded_file($file['tmp_name'])) {
            $ext=strtolower(pathinfo((string)$file['name'],PATHINFO_EXTENSION));
            $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($file['tmp_name']) ?: 'application/octet-stream';
            if (!isset($allowedTypes[$ext]) || !in_array($mime,$allowedTypes[$ext],true)) $errors[]='Allowed file types: PDF, PNG, JPG, DOC and DOCX.';
        } else { $ext=''; $mime=''; }
        if (!$errors && $file) {
            $stored=bin2hex(random_bytes(20)).'.'.$ext; $destination=$uploadDir.'/'.$stored;
            if (!move_uploaded_file($file['tmp_name'],$destination)) $errors[]='The upload could not be stored. Check the folder permissions.';
            else {
                try {
                    $stmt=$pdo->prepare('INSERT INTO crew_documents (crew_id,document_type,original_name,stored_name,mime_type,file_size,expiry_date,uploaded_by) VALUES (?,?,?,?,?,?,?,?)');
                    $stmt->execute([$crewId,$docType,substr(basename((string)$file['name']),0,255),$stored,$mime,(int)$file['size'],$expiry?:null,(int)$user['id']]);
                    $newId=(int)$pdo->lastInsertId(); log_activity('upload','crew_document',$newId,'Uploaded '.$docType); flash('success','Crew document uploaded securely.'); redirect('crew_documents.php');
                } catch (Throwable $exception) { @unlink($destination); $errors[]='Document details could not be saved to the database.'; }
            }
        }
    }
}
$crew=$pdo->query('SELECT id,full_name,rank_title FROM crew_members ORDER BY full_name')->fetchAll();
$q=trim((string)($_GET['q']??'')); $sql='SELECT d.*,c.full_name,c.rank_title,u.full_name AS uploader_name FROM crew_documents d JOIN crew_members c ON c.id=d.crew_id LEFT JOIN users u ON u.id=d.uploaded_by'; $params=[];
if($q!==''){$sql.=' WHERE c.full_name LIKE ? OR d.document_type LIKE ? OR d.original_name LIKE ?';$params=['%'.$q.'%','%'.$q.'%','%'.$q.'%'];}$sql.=' ORDER BY d.uploaded_at DESC LIMIT 500';$stmt=$pdo->prepare($sql);$stmt->execute($params);$docs=$stmt->fetchAll();
$pageTitle='Crew Documents';$activeNav='crew_documents.php';require __DIR__.'/includes/layout_top.php';
?>
<div class="page-heading"><div><div class="eyebrow">Crew records / Document vault</div><h1>Crew Documents</h1><p>Store crew certificates, identification records and expiry dates in private server storage.</p></div><div class="heading-actions"><span class="badge info">Maximum 5 MB per file</span></div></div>
<?php foreach($errors as $error):?><div class="alert error" data-dismiss><?=e($error)?><button class="alert-close" type="button" data-dismiss-button>×</button></div><?php endforeach;?>
<div class="module-grid"><section class="form-panel"><h2 class="form-title">Upload a document</h2><p class="form-description">Supported formats: PDF, PNG, JPG/JPEG, DOC and DOCX.</p><form method="post" enctype="multipart/form-data" action="crew_documents.php"><?=csrf_field()?><input type="hidden" name="action" value="upload"><div class="form-grid"><div class="field full"><label for="crew_id">Crew member *</label><select id="crew_id" name="crew_id" required><option value="">Choose crew member…</option><?php foreach($crew as $c):?><option value="<?=(int)$c['id']?>"><?=e($c['full_name'])?> — <?=e($c['rank_title'])?></option><?php endforeach;?></select></div><div class="field full"><label for="document_type">Document type *</label><select id="document_type" name="document_type" required><option value="">Choose document type…</option><?php foreach(['Passport','Seafarer book','Certificate of competency','Medical certificate','Safety training','Visa','Employment contract','Other'] as $type):?><option value="<?=e($type)?>"><?=e($type)?></option><?php endforeach;?></select></div><div class="field full"><label for="expiry_date">Expiry date (optional)</label><input id="expiry_date" name="expiry_date" type="date"></div><div class="field full"><label for="document">Document file *</label><input id="document" name="document" type="file" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" required><small>Files are stored under randomized server filenames. Do not upload files you are not authorized to retain.</small></div></div><div class="form-actions"><button class="btn btn-primary" type="submit">Upload document</button></div></form></section>
<section class="table-panel"><div class="table-head"><div><h2>Stored documents</h2><p><?=count($docs)?> documents<?= $q!==''?' matching “'.e($q).'”':''?></p></div></div><div class="table-tools"><form class="search-form" method="get"><input class="filter-control" name="q" value="<?=e($q)?>" placeholder="Search crew or document type…"><button class="btn btn-primary" type="submit">Search</button><?php if($q!==''):?><a class="btn btn-light" href="crew_documents.php">Clear</a><?php endif;?></form></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Document</th><th>Crew member</th><th>Expiry</th><th>Uploaded</th><th>Actions</th></tr></thead><tbody><?php if(!$docs):?><tr><td colspan="5"><div class="empty-state"><strong>No documents found</strong>Upload certificates or other crew records.</div></td></tr><?php else:foreach($docs as $d):?><tr><td class="primary-cell"><?=e($d['document_type'])?><span class="sub-cell"><?=e($d['original_name'])?> · <?=number_format((int)$d['file_size']/1024)?> KB</span></td><td><?=e($d['full_name'])?><span class="sub-cell"><?=e($d['rank_title'])?></span></td><td><?php if($d['expiry_date']):?><span class="badge <?=strtotime($d['expiry_date'])<strtotime(date('Y-m-d'))?'bad':(strtotime($d['expiry_date'])<strtotime('+60 days')?'warn':'good')?>"><?=e(date('d M Y',strtotime($d['expiry_date'])))?></span><?php else:?>—<?php endif;?></td><td><?=e(date('d M Y',strtotime($d['uploaded_at'])))?><span class="sub-cell">by <?=e($d['uploader_name']??'System')?></span></td><td><div class="inline-actions"><a class="btn btn-light btn-sm" href="download_crew_document.php?id=<?=(int)$d['id']?>">Download</a><?php if(is_admin()):?><form method="post" data-confirm="Permanently delete this document?"><?=csrf_field()?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$d['id']?>"><button class="btn btn-danger btn-sm" type="submit">Delete</button></form><?php endif;?></div></td></tr><?php endforeach;endif;?></tbody></table></div><div class="table-foot">Expiry alerts are indicated for expired or soon-to-expire documents. Keep backups in line with your organization's retention policy.</div></section></div>
<?php require __DIR__.'/includes/layout_bottom.php';?>
