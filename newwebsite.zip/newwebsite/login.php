<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$existing=current_user();if($existing)redirect(($existing['role']??'')==='crew'?'crew_portal.php':'dashboard.php');
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();$email=strtolower(trim((string)($_POST['email']??'')));$password=(string)($_POST['password']??'');$ip=substr((string)($_SERVER['REMOTE_ADDR']??'unknown'),0,45);
    try{
        $limit=db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE (email=? OR ip_address=?) AND attempted_at>DATE_SUB(NOW(), INTERVAL 15 MINUTE)');$limit->execute([$email,$ip]);
        if((int)$limit->fetchColumn()>=10){$error='Too many sign-in attempts. Please try again in 15 minutes.';}
        else{
            $stmt=db()->prepare('SELECT id,full_name,email,password_hash,role,status FROM users WHERE email=? LIMIT 1');$stmt->execute([$email]);$account=$stmt->fetch();
            if($account && $account['status']==='active' && password_verify($password,$account['password_hash'])){
                session_regenerate_id(true);unset($_SESSION['_csrf']);$_SESSION['user_id']=(int)$account['id'];
                db()->prepare('DELETE FROM login_attempts WHERE email=? OR ip_address=?')->execute([$email,$ip]);db()->prepare('UPDATE users SET last_login_at=NOW() WHERE id=?')->execute([$account['id']]);
                log_activity('login','users',(int)$account['id'],'Successful sign in');redirect($account['role']==='crew'?'crew_portal.php':'dashboard.php');
            }
            db()->prepare('INSERT INTO login_attempts (email,ip_address) VALUES (?,?)')->execute([$email,$ip]);$error='The email or password is incorrect, or the account is inactive.';
        }
    }catch(Throwable $exception){$error='Could not connect to the database. Check config/config.php and import database/schema.sql.';}
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Sign in · Atlantis Ship Management</title><link rel="stylesheet" href="assets/style.css"></head><body><main class="login-page"><section class="login-brand"><div class="brand-mark">A</div><h1>Command your fleet.<br><span>Navigate with clarity.</span></h1><p>A single workspace for vessel management, crew operations, shipment bookings, maintenance schedules and business reporting.</p><div class="login-features"><span>Fleet intelligence</span><span>Crew operations</span><span>Cargo tracking</span><span>Secure access</span></div></section><section class="login-card"><div class="eyebrow">Atlantis / Operations portal</div><h2>Welcome back.</h2><p>Sign in with your account to access your authorized workspace.</p><?php if($error):?><div class="alert error" data-dismiss><?=e($error)?><button class="alert-close" type="button" data-dismiss-button>×</button></div><?php endif;?><form method="post" action="login.php" autocomplete="on"><?=csrf_field()?><div class="field"><label for="email">Email address</label><input id="email" name="email" type="email" required autocomplete="username" value="<?=e($_POST['email']??'')?>"></div><div class="field"><label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="current-password"></div><button class="btn btn-primary" type="submit">Sign in to workspace →</button></form><div class="login-security">🔒 Role-based permissions · Protected sign-in</div><p class="help-text" style="margin:16px 0 0;text-align:center">First time? Configure the database, then visit <a href="setup.php">initial setup</a>.</p><p class="help-text" style="margin:10px 0 0;text-align:center"><a href="track.php">Track a shipment without signing in →</a></p></section></main></body></html>
