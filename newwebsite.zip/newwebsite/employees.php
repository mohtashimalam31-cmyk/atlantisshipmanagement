<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$user = require_login(['admin']);
$pdo = db(); $errors=[]; $editing=null;
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf(); $action=(string)($_POST['action']??'save'); $id=(int)($_POST['id']??0);
    if ($action==='toggle' && $id>0) {
        $stmt=$pdo->prepare("SELECT id,role,status FROM users WHERE id=? AND role IN ('employee','crew')"); $stmt->execute([$id]); $target=$stmt->fetch();
        if ($target) { $next=$target['status']==='active'?'inactive':'active'; $pdo->prepare('UPDATE users SET status=? WHERE id=?')->execute([$next,$id]); log_activity('status_change','user',$id,'Changed account status to '.$next); flash('success','Account status updated.'); }
        redirect('employees.php');
    }
    if ($action==='save') {
        $full=trim((string)($_POST['full_name']??'')); $email=strtolower(trim((string)($_POST['email']??''))); $phone=trim((string)($_POST['phone']??'')); $role=(string)($_POST['role']??'employee'); $status=(string)($_POST['status']??'active'); $password=(string)($_POST['password']??'');
        if ($full==='') $errors[]='Full name is required.';
        if (!filter_var($email,FILTER_VALIDATE_EMAIL)) $errors[]='Enter a valid email address.';
        if (!in_array($role,['employee','crew'],true)) $errors[]='Choose a valid role.';
        if (!in_array($status,['active','inactive'],true)) $errors[]='Choose a valid account status.';
        if ($id===0 && strlen($password)<12) $errors[]='New accounts need a password with at least 12 characters.';
        if ($password!=='' && strlen($password)<12) $errors[]='Passwords must contain at least 12 characters.';
        $stmt=$pdo->prepare('SELECT id FROM users WHERE email=? AND id<>? LIMIT 1'); $stmt->execute([$email,$id]); if ($stmt->fetchColumn()) $errors[]='That email address is already attached to an account.';
        if ($id>0) { $stmt=$pdo->prepare("SELECT id FROM users WHERE id=? AND role IN ('employee','crew')"); $stmt->execute([$id]); if (!$stmt->fetchColumn()) $errors[]='That account cannot be edited from this page.'; }
        if (!$errors) {
            try {
                if ($id>0) {
                    $sql='UPDATE users SET full_name=?,email=?,phone=?,role=?,status=?'; $args=[$full,$email,$phone?:null,$role,$status];
                    if ($password!=='') { $sql.=',password_hash=?'; $args[]=password_hash($password,PASSWORD_DEFAULT); }
                    $sql.=' WHERE id=?'; $args[]=$id; $pdo->prepare($sql)->execute($args); log_activity('update','user',$id,'Updated employee/crew account'); flash('success','Account updated successfully.');
                } else {
                    $stmt=$pdo->prepare('INSERT INTO users (full_name,email,phone,password_hash,role,status) VALUES (?,?,?,?,?,?)'); $stmt->execute([$full,$email,$phone?:null,password_hash($password,PASSWORD_DEFAULT),$role,$status]); $newId=(int)$pdo->lastInsertId(); log_activity('create','user',$newId,'Created '.$role.' account'); flash('success','Account created. Give the user their login details securely.');
                }
                redirect('employees.php');
            } catch (Throwable $exception) { $errors[]='Account could not be saved. Please check the details.'; }
        }
        $editing=['id'=>$id,'full_name'=>$full,'email'=>$email,'phone'=>$phone,'role'=>$role,'status'=>$status];
    }
}
$editId=(int)($_GET['edit']??0);
if ($editId>0 && !$editing) { $stmt=$pdo->prepare("SELECT id,full_name,email,phone,role,status FROM users WHERE id=? AND role IN ('employee','crew')"); $stmt->execute([$editId]); $editing=$stmt->fetch()?:null; }
$q=trim((string)($_GET['q']??'')); $sql="SELECT id,full_name,email,phone,role,status,last_login_at,created_at FROM users WHERE role IN ('employee','crew')"; $params=[];
if ($q!=='') { $sql.=' AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ? OR role LIKE ?)'; for($i=0;$i<4;$i++) $params[]='%'.$q.'%'; }
$sql.=' ORDER BY created_at DESC LIMIT 500'; $stmt=$pdo->prepare($sql); $stmt->execute($params); $accounts=$stmt->fetchAll();
$pageTitle='Employees & Access'; $activeNav='employees.php'; require __DIR__.'/includes/layout_top.php';
?>
<div class="page-heading"><div><div class="eyebrow">Administration / Access control</div><h1>Employees & Access</h1><p>Create employee and crew portal accounts, change roles, or suspend access.</p></div><div class="heading-actions"><span class="badge info">Administrator only</span></div></div>
<?php foreach($errors as $error): ?><div class="alert error" data-dismiss><?=e($error)?><button class="alert-close" type="button" data-dismiss-button>×</button></div><?php endforeach; ?>
<div class="module-grid"><section class="form-panel" id="record-form"><h2 class="form-title"><?=$editing?'Edit account':'Create account'?></h2><p class="form-description">Employees can manage operations. Crew accounts have access to the crew portal only.</p>
<form method="post" action="employees.php" autocomplete="off"><?=csrf_field()?> <input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=e($editing['id']??0)?>"><div class="form-grid">
<div class="field full"><label for="full_name">Full name *</label><input id="full_name" name="full_name" required value="<?=e($editing['full_name']??'')?>"></div>
<div class="field full"><label for="email">Email / username *</label><input type="email" id="email" name="email" required value="<?=e($editing['email']??'')?>"><small>Crew portal accounts link to the crew profile with the same email address.</small></div>
<div class="field"><label for="phone">Phone</label><input type="tel" id="phone" name="phone" value="<?=e($editing['phone']??'')?>"></div>
<div class="field"><label for="role">Role *</label><select id="role" name="role" required><option value="employee" <?=($editing['role']??'employee')==='employee'?'selected':''?>>Employee</option><option value="crew" <?=($editing['role']??'')==='crew'?'selected':''?>>Crew portal</option></select></div>
<div class="field"><label for="status">Account status *</label><select id="status" name="status" required><option value="active" <?=($editing['status']??'active')==='active'?'selected':''?>>Active</option><option value="inactive" <?=($editing['status']??'')==='inactive'?'selected':''?>>Inactive</option></select></div>
<div class="field full"><label for="password">Password <?=$editing?'(leave blank to keep current)':'*'?></label><input type="password" id="password" name="password" <?=!$editing?'required':''?> minlength="12" autocomplete="new-password"><small>Use at least 12 characters. Give passwords to users through a secure channel.</small></div>
</div><div class="form-actions"><button class="btn btn-primary" type="submit"><?=$editing?'Save account':'Create account'?></button><?php if($editing):?><a class="btn btn-light" href="employees.php">Cancel</a><?php endif;?></div></form></section>
<section class="table-panel"><div class="table-head"><div><h2>Employee & crew accounts</h2><p><?=count($accounts)?> accounts · administrator accounts are not managed here</p></div></div><div class="table-tools"><form class="search-form" method="get"><input class="filter-control" name="q" value="<?=e($q)?>" placeholder="Search by name, email, phone…"><button class="btn btn-primary" type="submit">Search</button><?php if($q!==''):?><a class="btn btn-light" href="employees.php">Clear</a><?php endif;?></form></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Account</th><th>Role</th><th>Last login</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php if(!$accounts):?><tr><td colspan="5"><div class="empty-state"><strong>No accounts found</strong>Create an employee or crew portal login.</div></td></tr><?php else: foreach($accounts as $a):?><tr><td class="primary-cell"><?=e($a['full_name'])?><span class="sub-cell"><?=e($a['email'])?><?= $a['phone']?' · '.e($a['phone']):''?></span></td><td><?=e(humanize($a['role']))?></td><td><?= $a['last_login_at']?e(date('d M Y H:i',strtotime($a['last_login_at']))):'Never'?></td><td><span class="badge <?=e(status_class($a['status']))?>"><?=e(humanize($a['status']))?></span></td><td><div class="inline-actions"><a class="btn btn-light btn-sm" href="employees.php?edit=<?=(int)$a['id']?>#record-form">Edit</a><form method="post" data-confirm="Change this account's access status?"><?=csrf_field()?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?=(int)$a['id']?>"><button class="btn <?= $a['status']==='active'?'btn-danger':'btn-primary'?> btn-sm" type="submit"><?=$a['status']==='active'?'Suspend':'Activate'?></button></form></div></td></tr><?php endforeach; endif;?></tbody></table></div><div class="table-foot">Suspended accounts cannot sign in. Crew profiles remain managed from the Crew Members page.</div></section></div>
<?php require __DIR__.'/includes/layout_bottom.php'; ?>
