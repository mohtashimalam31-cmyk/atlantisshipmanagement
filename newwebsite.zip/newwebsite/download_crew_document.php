<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$user=require_login(['admin','employee','crew']);
$id=(int)($_GET['id']??0); $stmt=db()->prepare('SELECT d.*,c.email AS crew_email,c.full_name FROM crew_documents d JOIN crew_members c ON c.id=d.crew_id WHERE d.id=?');$stmt->execute([$id]);$doc=$stmt->fetch();
if(!$doc){http_response_code(404);exit('Document not found.');}
if($user['role']==='crew' && (!$doc['crew_email'] || strcasecmp((string)$doc['crew_email'],(string)$user['email'])!==0)){http_response_code(403);exit('You cannot access this document.');}
$path=app_config()['uploads_dir'].'/'.$doc['stored_name'];
if(!is_file($path)){http_response_code(404);exit('The stored file is missing.');}
$allowedMime=['application/pdf','image/png','image/jpeg','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/zip'];
if(!in_array($doc['mime_type'],$allowedMime,true)){http_response_code(415);exit('This file type cannot be downloaded.');}
$filename=preg_replace('/[^A-Za-z0-9._ -]/','_',basename((string)$doc['original_name']));
header('Content-Type: '.$doc['mime_type']);header('Content-Length: '.filesize($path));header('Content-Disposition: attachment; filename="'.str_replace(['"',"\r","\n"],'',$filename).'"');header('X-Content-Type-Options: nosniff');header('Cache-Control: private, no-store');readfile($path);exit;
