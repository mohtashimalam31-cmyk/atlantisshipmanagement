-- Atlantis Ship Management database schema (MySQL 8.0+ / MariaDB 10.5+)
CREATE DATABASE IF NOT EXISTS atlantis_ship_management
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE atlantis_ship_management;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(40) NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','employee','crew') NOT NULL DEFAULT 'employee',
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  last_login_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_role_status (role, status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ships (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  vessel_name VARCHAR(160) NOT NULL,
  imo_number VARCHAR(20) NULL UNIQUE,
  vessel_type VARCHAR(60) NOT NULL DEFAULT 'general_cargo',
  flag VARCHAR(80) NULL,
  capacity_tons DECIMAL(12,2) NULL,
  year_built SMALLINT UNSIGNED NULL,
  status ENUM('available','scheduled','at_sea','maintenance','inactive') NOT NULL DEFAULT 'available',
  notes TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_ships_status (status),
  INDEX idx_ships_name (vessel_name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS crew_members (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(160) NOT NULL,
  rank_title VARCHAR(100) NOT NULL,
  nationality VARCHAR(80) NULL,
  certificate_no VARCHAR(100) NULL UNIQUE,
  certificate_expiry DATE NULL,
  phone VARCHAR(40) NULL,
  email VARCHAR(190) NULL,
  status ENUM('available','assigned','on_leave','inactive') NOT NULL DEFAULT 'available',
  notes TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_crew_name (full_name),
  INDEX idx_crew_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS crew_assignments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  crew_id BIGINT UNSIGNED NOT NULL,
  ship_id BIGINT UNSIGNED NOT NULL,
  role_onboard VARCHAR(100) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NULL,
  status ENUM('planned','active','completed','cancelled') NOT NULL DEFAULT 'planned',
  notes TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_assign_crew FOREIGN KEY (crew_id) REFERENCES crew_members(id) ON DELETE RESTRICT,
  CONSTRAINT fk_assign_ship FOREIGN KEY (ship_id) REFERENCES ships(id) ON DELETE RESTRICT,
  INDEX idx_assign_dates (start_date, end_date),
  INDEX idx_assign_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS crew_documents (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  crew_id BIGINT UNSIGNED NOT NULL,
  document_type VARCHAR(100) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(255) NOT NULL UNIQUE,
  mime_type VARCHAR(120) NOT NULL,
  file_size BIGINT UNSIGNED NOT NULL,
  expiry_date DATE NULL,
  uploaded_by BIGINT UNSIGNED NULL,
  uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_docs_crew FOREIGN KEY (crew_id) REFERENCES crew_members(id) ON DELETE RESTRICT,
  CONSTRAINT fk_docs_user FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_docs_expiry (expiry_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customers (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  company_name VARCHAR(180) NOT NULL,
  contact_name VARCHAR(140) NULL,
  email VARCHAR(190) NULL,
  phone VARCHAR(40) NULL,
  address TEXT NULL,
  notes TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_customers_company (company_name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS bookings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  booking_ref VARCHAR(40) NOT NULL UNIQUE,
  customer_id BIGINT UNSIGNED NOT NULL,
  ship_id BIGINT UNSIGNED NULL,
  origin_port VARCHAR(160) NOT NULL,
  destination_port VARCHAR(160) NOT NULL,
  booking_date DATE NOT NULL,
  expected_arrival DATE NULL,
  cargo_description TEXT NOT NULL,
  cargo_weight_tons DECIMAL(12,2) NULL,
  status ENUM('pending','confirmed','in_transit','delivered','cancelled') NOT NULL DEFAULT 'pending',
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_booking_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE RESTRICT,
  CONSTRAINT fk_booking_ship FOREIGN KEY (ship_id) REFERENCES ships(id) ON DELETE SET NULL,
  CONSTRAINT fk_booking_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_booking_status (status),
  INDEX idx_booking_date (booking_date),
  INDEX idx_booking_route (origin_port, destination_port)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS maintenance_records (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ship_id BIGINT UNSIGNED NOT NULL,
  maintenance_type VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  scheduled_date DATE NOT NULL,
  completed_date DATE NULL,
  cost DECIMAL(12,2) NULL,
  status ENUM('planned','in_progress','completed','cancelled') NOT NULL DEFAULT 'planned',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_maintenance_ship FOREIGN KEY (ship_id) REFERENCES ships(id) ON DELETE RESTRICT,
  INDEX idx_maintenance_date (scheduled_date),
  INDEX idx_maintenance_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS schedules (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ship_id BIGINT UNSIGNED NOT NULL,
  port_name VARCHAR(160) NOT NULL,
  arrival_datetime DATETIME NULL,
  departure_datetime DATETIME NULL,
  status ENUM('planned','arrived','departed','delayed','cancelled') NOT NULL DEFAULT 'planned',
  notes TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_schedule_ship FOREIGN KEY (ship_id) REFERENCES ships(id) ON DELETE RESTRICT,
  INDEX idx_schedule_arrival (arrival_datetime),
  INDEX idx_schedule_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS login_attempts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_login_email_time (email, attempted_at),
  INDEX idx_login_ip_time (ip_address, attempted_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100) NULL,
  entity_id BIGINT UNSIGNED NULL,
  details VARCHAR(500) NULL,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_audit_created (created_at),
  INDEX idx_audit_entity (entity_type, entity_id)
) ENGINE=InnoDB;
