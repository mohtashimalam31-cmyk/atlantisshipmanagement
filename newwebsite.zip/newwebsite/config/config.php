<?php
/**
 * Atlantis Ship Management configuration.
 * Change these values for your local XAMPP/WAMP or production MySQL database.
 */
return [
    'app_name' => 'Atlantis Ship Management',
    'app_url' => '', // Optional, e.g. https://example.com/atlantis
    'timezone' => 'Asia/Karachi',
    'session_name' => 'ATLANTIS_SESSION',
    'database' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'atlantis_ship_management',
        'username' => 'root',
        'password' => '', // Set a strong password on production hosting.
        'charset' => 'utf8mb4',
    ],
    'uploads_dir' => __DIR__ . '/../uploads/crew_docs',
    'max_upload_bytes' => 5 * 1024 * 1024,
];
