(() => {
  const menu = document.querySelector('[data-menu-toggle]');
  const sidebar = document.getElementById('sidebar');
  if (menu && sidebar) menu.addEventListener('click', () => sidebar.classList.toggle('open'));
  document.querySelectorAll('[data-dismiss-button]').forEach((button) => {
    button.addEventListener('click', () => button.closest('[data-dismiss]')?.remove());
  });
  document.querySelectorAll('[data-confirm]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      const message = form.getAttribute('data-confirm') || 'Are you sure?';
      if (!window.confirm(message)) event.preventDefault();
    });
  });
})();
