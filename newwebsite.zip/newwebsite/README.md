# Atlantis Ship Management — PHP + MySQL

A standalone, responsive PHP/MySQL management portal covering the requested fleet, crew, customer, cargo and reporting workflows. The package is not a patched copy of the original Lovable frontend because the uploaded ZIP was damaged and could not be reliably extracted. The UI can be merged with a healthy Lovable export later through the endpoints/pages in this project.

## Features included

- **Admin dashboard:** vessel, available-fleet, crew, shipment, customer and maintenance metrics; recent bookings and quick actions.
- **Ship management:** vessel details, IMO number, type, flag, capacity, year built, availability/status and notes.
- **Crew management:** seafarer profiles, rank, nationality, certificate details, contact information and availability.
- **Crew assignments:** link a crew member to a vessel, role on board, start/end dates and assignment status.
- **Crew document vault:** upload approved PDF, PNG, JPG/JPEG, DOC and DOCX documents (5 MB per file); record type and expiry; download authorization; admin-only deletion.
- **Customers:** company, contact, email, phone, address and account notes.
- **Bookings and cargo:** generated booking reference, customer, vessel, ports, booking/arrival dates, cargo description, weight and shipment status.
- **Vessel maintenance:** planned/in-progress/completed maintenance, dates, descriptions and costs.
- **Schedules:** port calls and vessel arrival/departure dates and times.
- **Authentication and roles:** password hashes, session regeneration, CSRF protection, sign-in throttling, admin/employee/crew roles, and active/inactive accounts.
- **Crew portal:** crew users can view their linked profile, assignments and authorized documents. The login email must match the crew profile email.
- **Reports:** searchable datasets with date range filters and CSV export. CSV values beginning with formula characters are escaped.
- **Audit trail:** core create/update/delete/login actions are recorded in `audit_logs`.
- **Public tracking:** `track.php?ref=BOOKING_REFERENCE` shows limited shipment route/status information without exposing customer account data.

## Requirements

- PHP 8.1+ (tested for syntax using PHP 8.4)
- MySQL 8+ or a compatible MariaDB version
- PHP extensions: `pdo_mysql`, `fileinfo`, `session`
- Apache hosting with `.htaccess` support is recommended. On Nginx, translate the deny rules in `.htaccess` into server configuration rules.

## Install locally (XAMPP on Windows)

1. Extract this folder into `C:\xampp\htdocs\Atlantis_Ship_Management_PHP`.
2. Start **Apache** and **MySQL** from XAMPP.
3. Open phpMyAdmin (usually `http://localhost/phpmyadmin`) and import `database/schema.sql`. It creates a database called `atlantis_ship_management` and all required tables.
4. Edit `config/config.php` and set the correct database host, name, username and password. The file defaults to `127.0.0.1`, database `atlantis_ship_management`, username `root`, and an empty password for a typical fresh local XAMPP installation only.
5. Ensure `uploads/crew_docs` is writable by PHP. It is deliberately blocked from direct HTTP access; file downloads go through an authenticated PHP route.
6. Visit `http://localhost/Atlantis_Ship_Management_PHP/setup.php` and create the first administrator with a strong password (12 characters minimum).
7. Sign in at `http://localhost/Atlantis_Ship_Management_PHP/login.php`.

## Hosting deployment

1. Create a MySQL database and a dedicated DB user in your hosting panel; grant that user privileges only on this database.
2. Import `database/schema.sql`. If your hosting provider does not permit `CREATE DATABASE`, create the database via the control panel and import the table statements after removing the opening `CREATE DATABASE` and `USE atlantis_ship_management` lines.
3. Configure `config/config.php` with the hosting database credentials. Never commit this file to a public repository.
4. Enable HTTPS. Confirm `.htaccess` deny rules are honored, or configure equivalent restrictions in your web server (especially for `config/`, `database/`, `includes/`, and `uploads/`).
5. Create the initial admin through `setup.php`. It redirects to login once an administrator exists. For extra hardening, remove or restrict access to `setup.php` after first setup.
6. Create employee or crew accounts from **Employees & Access**. Crew logins can see a profile only when their login email matches a record in Crew Members.
7. Back up both the database and the document storage directory using your organization's retention and privacy policy.

## Using the application

Sign in and start by adding ships, crew members, and customers. Then create crew assignments, bookings, maintenance tasks and schedule stops. Reports are available from the side menu and can be exported to CSV. The public tracking page is available at `/track.php` once bookings exist.

## Data / operational notes

- The application provides a general-purpose management foundation, not a certified maritime compliance or voyage-navigation system.
- CSV reports are capped at 1,000 returned rows per request; use search/date filters for larger databases.
- Uploaded files are limited to 5 MB, extension-checked and MIME-checked, stored with random filenames and served through access-controlled downloads.
- Employees may create/update standard operational records. Only admins can delete records, upload accounts or change employee/crew account access. Foreign-key constraints prevent deleting records that remain linked.
- Production deployment should add scheduled database backups, monitoring, account recovery policy, and HTTPS-enforced hosting.

## Project structure

- `database/schema.sql` — database and tables
- `config/config.php` — local/server settings
- `includes/` — authentication helpers, navigation, module engine and module definitions
- `dashboard.php` — operations overview
- `ships.php`, `crew.php`, `crew_assignments.php`, `customers.php`, `bookings.php`, `maintenance.php`, `schedules.php` — operational modules
- `crew_documents.php`, `employees.php`, `crew_portal.php` — document vault and access management
- `reports.php`, `track.php` — CSV reporting and public shipment tracking
