<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$moduleKey = 'crew';
require __DIR__ . '/includes/manage_module.php';
