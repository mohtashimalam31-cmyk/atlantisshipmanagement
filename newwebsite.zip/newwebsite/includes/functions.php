<?php
declare(strict_types=1);

function app_config(): array { return $GLOBALS['config']; }

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $d = app_config()['database'];
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $d['host'], $d['port'], $d['name'], $d['charset']);
    $pdo = new PDO($dsn, $d['username'], $d['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function e(mixed $value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function redirect(string $url): never { header('Location: ' . $url); exit; }
function csrf_token(): string { if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void {
    $provided = $_POST['_csrf'] ?? '';
    if (!is_string($provided) || !hash_equals(csrf_token(), $provided)) {
        http_response_code(419); exit('Your session token expired. Please go back, refresh, and try again.');
    }
}
function flash(string $type, string $message): void { $_SESSION['_flashes'][] = ['type' => $type, 'message' => $message]; }
function take_flashes(): array { $items = $_SESSION['_flashes'] ?? []; unset($_SESSION['_flashes']); return $items; }

function current_user(): ?array {
    static $loaded = false, $user = null;
    if ($loaded) return $user;
    $loaded = true;
    if (empty($_SESSION['user_id'])) return null;
    try {
        $stmt = db()->prepare('SELECT id, full_name, email, phone, role, status FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$_SESSION['user_id']]);
        $candidate = $stmt->fetch();
        if ($candidate && $candidate['status'] === 'active') $user = $candidate;
        else unset($_SESSION['user_id']);
    } catch (Throwable $exception) {
        $user = null;
    }
    return $user;
}
function require_login(array $roles = []): array {
    $user = current_user();
    if (!$user) redirect('login.php');
    if ($roles && !in_array($user['role'], $roles, true)) {
        http_response_code(403);
        render_forbidden();
        exit;
    }
    return $user;
}
function render_forbidden(): void {
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Access denied</title><body style="font:16px Arial;background:#f4f7fb;padding:4rem;color:#102235"><h1>Access denied</h1><p>Your account does not have permission to open this page.</p><p><a href="dashboard.php">Return to dashboard</a></p></body></html>';
}
function is_admin(): bool { return (current_user()['role'] ?? '') === 'admin'; }
function log_activity(string $action, ?string $entityType = null, ?int $entityId = null, ?string $details = null): void {
    try {
        $u = current_user();
        $userId = $u['id'] ?? (isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null);
        $stmt = db()->prepare('INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([$userId, $action, $entityType, $entityId, $details ? substr($details, 0, 500) : null, $_SERVER['REMOTE_ADDR'] ?? null]);
    } catch (Throwable $exception) { /* Auditing must not block the main operation. */ }
}
function humanize(string $value): string { return ucwords(str_replace(['_', '-'], ' ', $value)); }
function status_class(string $status): string {
    return match ($status) {
        'available', 'active', 'delivered', 'completed', 'arrived' => 'good',
        'pending', 'planned', 'scheduled', 'in_progress', 'delayed', 'on_leave' => 'warn',
        'cancelled', 'inactive', 'maintenance' => 'bad',
        'in_transit', 'at_sea', 'confirmed', 'assigned', 'departed' => 'info',
        default => 'neutral',
    };
}
function safe_csv_cell(mixed $value): string {
    $value = (string)($value ?? '');
    if ($value !== '' && preg_match('/^[\s]*[=+@\-]/u', $value)) $value = "'" . $value;
    return $value;
}
