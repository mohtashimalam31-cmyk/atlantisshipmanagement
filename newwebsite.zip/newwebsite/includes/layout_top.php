<?php
$pageTitle = $pageTitle ?? 'Dashboard';
$activeNav = $activeNav ?? '';
$user = current_user();
$role = $user['role'] ?? '';
$nav = [
 ['label'=>'Overview','url'=>'dashboard.php','icon'=>'◫','roles'=>['admin','employee']],
 ['label'=>'Ships & Vessels','url'=>'ships.php','icon'=>'⚓','roles'=>['admin','employee']],
 ['label'=>'Crew Members','url'=>'crew.php','icon'=>'♙','roles'=>['admin','employee']],
 ['label'=>'Crew Assignments','url'=>'crew_assignments.php','icon'=>'⇄','roles'=>['admin','employee']],
 ['label'=>'Crew Documents','url'=>'crew_documents.php','icon'=>'▤','roles'=>['admin','employee']],
 ['label'=>'Customers','url'=>'customers.php','icon'=>'♧','roles'=>['admin','employee']],
 ['label'=>'Bookings & Cargo','url'=>'bookings.php','icon'=>'▣','roles'=>['admin','employee']],
 ['label'=>'Maintenance','url'=>'maintenance.php','icon'=>'⚙','roles'=>['admin','employee']],
 ['label'=>'Schedules','url'=>'schedules.php','icon'=>'◷','roles'=>['admin','employee']],
 ['label'=>'Reports','url'=>'reports.php','icon'=>'▥','roles'=>['admin','employee']],
 ['label'=>'Employees & Access','url'=>'employees.php','icon'=>'♙','roles'=>['admin']],
];
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= e($pageTitle) ?> · Atlantis Ship Management</title><link rel="stylesheet" href="assets/style.css"><script defer src="assets/app.js"></script></head><body class="app-page"><div class="app-shell"><aside class="sidebar" id="sidebar"><a class="sidebar-brand" href="dashboard.php"><div class="brand-mark mini">A</div><div><strong>ATLANTIS</strong><span>SHIP MANAGEMENT</span></div></a><div class="workspace-label">WORKSPACE</div><nav class="side-nav"><?php foreach ($nav as $item): if (!in_array($role, $item['roles'], true)) continue; ?><a class="nav-link <?= $activeNav === $item['url'] ? 'active' : '' ?>" href="<?= e($item['url']) ?>"><span class="nav-icon"><?= e($item['icon']) ?></span><span><?= e($item['label']) ?></span></a><?php endforeach; ?></nav><div class="sidebar-bottom"><div class="side-note"><span class="status-dot"></span><div><strong>System status</strong><small>Operational workspace</small></div></div><form action="logout.php" method="post"><?= csrf_field() ?><button class="nav-link logout-button" type="submit"><span class="nav-icon">↪</span><span>Sign out</span></button></form><div class="sidebar-copy">ATLANTIS · CONTROL CENTRE</div></div></aside><div class="main-area"><header class="topbar"><button class="mobile-menu" type="button" aria-label="Toggle menu" data-menu-toggle>☰</button><div class="breadcrumbs">Workspace <span>/</span> <strong><?= e($pageTitle) ?></strong></div><div class="top-user"><div class="avatar"><?= e(strtoupper(substr($user['full_name'] ?? 'A', 0, 1))) ?></div><div class="top-user-meta"><strong><?= e($user['full_name'] ?? 'User') ?></strong><small><?= e(humanize($role)) ?></small></div></div></header><main class="content-area"><?php foreach (take_flashes() as $notice): ?><div class="alert <?= e($notice['type']) ?>" data-dismiss><?= e($notice['message']) ?><button type="button" aria-label="Dismiss" class="alert-close" data-dismiss-button>×</button></div><?php endforeach; ?>
