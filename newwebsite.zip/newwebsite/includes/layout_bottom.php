</main><footer class="app-footer"><span>© <?= date('Y') ?> Atlantis Ship Management</span><span>Fleet operations · Crew · Cargo · Compliance</span></footer></div></div></body></html>
