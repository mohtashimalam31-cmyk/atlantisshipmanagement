<?php
declare(strict_types=1);
$modules = require __DIR__ . '/module_config.php';
if (!isset($moduleKey, $modules[$moduleKey])) { http_response_code(404); exit('Unknown module.'); }
$module = $modules[$moduleKey];
$user = require_login(['admin','employee']);
$pdo = db();
$errors = [];
$editing = null;

function module_options(array $source): array {
    $allowed = ['ships'=>['id','vessel_name'], 'crew_members'=>['id','full_name'], 'customers'=>['id','company_name']];
    if (!isset($allowed[$source['table']])) return [];
    [$valueField,$labelField] = $allowed[$source['table']];
    $stmt = db()->query("SELECT {$valueField}, {$labelField} FROM {$source['table']} ORDER BY {$labelField} ASC");
    $result = [];
    foreach ($stmt->fetchAll() as $row) $result[(string)$row[$valueField]] = $row[$labelField];
    return $result;
}
function module_render_value(array $column, mixed $value, array &$sourceMaps): string {
    if (isset($column['source'])) {
        $table = $column['source']['table'];
        if (!isset($sourceMaps[$table])) $sourceMaps[$table] = module_options($column['source']);
        return (string)($sourceMaps[$table][(string)$value] ?? '—');
    }
    if ($value === null || $value === '') return '—';
    if (!empty($column['humanize'])) return humanize((string)$value);
    if (!empty($column['status'])) return '<span class="badge ' . e(status_class((string)$value)) . '">' . e(humanize((string)$value)) . '</span>';
    if (str_ends_with((string)$column['key'], '_at') && $value) return e(date('d M Y, H:i', strtotime((string)$value)));
    if (in_array($column['key'], ['booking_date','expected_arrival','certificate_expiry','start_date','end_date','scheduled_date','completed_date'], true)) return e(date('d M Y', strtotime((string)$value)));
    if ($column['key'] === 'capacity_tons' || $column['key'] === 'cargo_weight_tons') return e(number_format((float)$value, 2));
    if ($column['key'] === 'cost') return e(number_format((float)$value, 2));
    return e($value);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string)($_POST['action'] ?? 'save');
    $id = (int)($_POST['id'] ?? 0);
    if ($action === 'delete') {
        if (!is_admin()) { http_response_code(403); exit('Only an administrator can delete records.'); }
        if ($id > 0) {
            try {
                $stmt = $pdo->prepare('DELETE FROM ' . $module['table'] . ' WHERE id = ?');
                $stmt->execute([$id]);
                log_activity('delete', $moduleKey, $id, 'Deleted ' . $module['singular']);
                flash('success', $module['singular'] . ' deleted successfully.');
            } catch (PDOException $ex) {
                flash('error', 'This record cannot be deleted because it is linked to other records. Update or remove the related records first.');
            }
        }
        redirect($module['active']);
    }
    if ($action === 'save') {
        $payload = [];
        foreach ($module['fields'] as $field) {
            $key = $field['key'];
            $raw = $_POST[$key] ?? '';
            $raw = is_string($raw) ? trim($raw) : '';
            if (($field['required'] ?? false) && $raw === '') $errors[] = $field['label'] . ' is required.';
            if (($field['type'] ?? '') === 'email' && $raw !== '' && !filter_var($raw, FILTER_VALIDATE_EMAIL)) $errors[] = $field['label'] . ' must be a valid email address.';
            if (($field['type'] ?? '') === 'source') {
                $opts = module_options($field['source']);
                if ($raw !== '' && !array_key_exists($raw, $opts)) $errors[] = 'Select a valid option for ' . $field['label'] . '.';
                if ($raw === '') $raw = null;
            }
            if (($field['type'] ?? '') === 'select') {
                if (!array_key_exists($raw, $field['options'] ?? [])) $errors[] = 'Select a valid option for ' . $field['label'] . '.';
            }
            if (in_array($field['type'] ?? '', ['number'], true) && $raw !== '' && !is_numeric($raw)) $errors[] = $field['label'] . ' must be a number.';
            if (in_array($field['type'] ?? '', ['number'], true) && $raw !== '' && (float)$raw < 0) $errors[] = $field['label'] . ' cannot be negative.';
            if ($raw === '' && in_array($field['type'] ?? '', ['date','datetime-local','number','email','tel','text','textarea'], true)) $raw = null;
            if (($field['type'] ?? '') === 'datetime-local' && $raw !== null) {
                $raw = str_replace('T', ' ', $raw);
                if (strlen($raw) === 16) $raw .= ':00';
                if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $raw)) $errors[] = $field['label'] . ' is invalid.';
            }
            if ($raw !== null && in_array($field['type'] ?? '', ['date'], true) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw)) $errors[] = $field['label'] . ' is invalid.';
            $payload[$key] = $raw;
        }
        if ($moduleKey === 'bookings' && !$id) {
            $payload['booking_ref'] = 'ATL-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
            $payload['created_by'] = (int)$user['id'];
        }
        if (!$errors) {
            try {
                if ($id > 0) {
                    $check = $pdo->prepare('SELECT id FROM ' . $module['table'] . ' WHERE id = ?');
                    $check->execute([$id]);
                    if (!$check->fetchColumn()) throw new RuntimeException('The record you are editing no longer exists.');
                    $set = array_map(static fn($key) => $key . ' = ?', array_keys($payload));
                    $stmt = $pdo->prepare('UPDATE ' . $module['table'] . ' SET ' . implode(', ', $set) . ' WHERE id = ?');
                    $stmt->execute([...array_values($payload), $id]);
                    log_activity('update', $moduleKey, $id, 'Updated ' . $module['singular']);
                    flash('success', $module['singular'] . ' updated successfully.');
                } else {
                    $keys = array_keys($payload);
                    $stmt = $pdo->prepare('INSERT INTO ' . $module['table'] . ' (' . implode(', ', $keys) . ') VALUES (' . implode(', ', array_fill(0, count($keys), '?')) . ')');
                    $stmt->execute(array_values($payload));
                    $newId = (int)$pdo->lastInsertId();
                    log_activity('create', $moduleKey, $newId, 'Created ' . $module['singular']);
                    flash('success', $module['singular'] . ' created successfully.');
                }
                redirect($module['active']);
            } catch (Throwable $exception) {
                $errors[] = $exception instanceof PDOException && (string)$exception->getCode() === '23000'
                    ? 'A unique value already exists or a related record is invalid. Please check the values and try again.'
                    : ($exception instanceof RuntimeException ? $exception->getMessage() : 'The record could not be saved. Check required fields and linked records.');
            }
        }
        $editing = ['id'=>$id] + $payload;
    }
}

$editId = (int)($_GET['edit'] ?? 0);
if ($editId > 0 && !$editing) {
    $stmt = $pdo->prepare('SELECT * FROM ' . $module['table'] . ' WHERE id = ?');
    $stmt->execute([$editId]);
    $editing = $stmt->fetch() ?: null;
    if (!$editing) flash('error', 'The requested record could not be found.');
}
$q = trim((string)($_GET['q'] ?? ''));
$sql = 'SELECT * FROM ' . $module['table'];
$params = [];
if ($q !== '') {
    $where = [];
    foreach ($module['search_fields'] as $field) { $where[] = $field . ' LIKE ?'; $params[] = '%' . $q . '%'; }
    $sql .= ' WHERE (' . implode(' OR ', $where) . ')';
}
$sql .= ' ORDER BY id DESC LIMIT 500';
$stmt = $pdo->prepare($sql); $stmt->execute($params); $rows = $stmt->fetchAll();
$sourceMaps = [];
foreach ($module['columns'] as $column) if (isset($column['source']) && !isset($sourceMaps[$column['source']['table']])) $sourceMaps[$column['source']['table']] = module_options($column['source']);

$pageTitle = $module['title']; $activeNav = $module['active'];
require __DIR__ . '/layout_top.php';
?>
<div class="page-heading"><div><div class="eyebrow">Fleet operations / Records</div><h1><?= e($module['title']) ?></h1><p><?= e($module['description']) ?></p></div><div class="heading-actions"><a class="btn btn-light" href="reports.php?dataset=<?= e($moduleKey) ?>">↗ View report</a><a class="btn btn-gold" href="<?= e($module['active']) ?>#record-form">＋ Add <?= e(strtolower($module['singular'])) ?></a></div></div>
<?php foreach ($errors as $error): ?><div class="alert error" data-dismiss><?= e($error) ?><button class="alert-close" type="button" data-dismiss-button>×</button></div><?php endforeach; ?>
<div class="module-grid">
  <section class="form-panel" id="record-form">
    <h2 class="form-title"><?= $editing ? 'Edit ' . e($module['singular']) : 'Add ' . e($module['singular']) ?></h2>
    <p class="form-description">Fields marked with * are required. Records are saved to your MySQL database.</p>
    <form method="post" action="<?= e($module['active']) ?>" autocomplete="off">
      <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= e($editing['id'] ?? 0) ?>">
      <div class="form-grid">
      <?php foreach ($module['fields'] as $field): $key=$field['key']; $value=$editing[$key] ?? ($field['default'] ?? ''); if (($field['type'] ?? '')==='datetime-local' && $value) $value=substr(str_replace(' ','T',(string)$value),0,16); if ($value===null) $value=''; $type=$field['type'] ?? 'text'; ?>
        <div class="field <?= !empty($field['full']) ? 'full' : '' ?>"><label for="field_<?= e($key) ?>"><?= e($field['label']) ?><?= !empty($field['required']) ? ' *' : '' ?></label>
          <?php if ($type === 'textarea'): ?><textarea id="field_<?= e($key) ?>" name="<?= e($key) ?>" <?= !empty($field['required'])?'required':'' ?>><?= e($value) ?></textarea>
          <?php elseif ($type === 'select' || $type === 'source'): $opts=$type==='source' ? module_options($field['source']) : $field['options']; ?><select id="field_<?= e($key) ?>" name="<?= e($key) ?>" <?= !empty($field['required'])?'required':'' ?>><option value="">Choose…</option><?php foreach ($opts as $optionValue=>$optionLabel): ?><option value="<?= e($optionValue) ?>" <?= (string)$value===(string)$optionValue?'selected':'' ?>><?= e($optionLabel) ?></option><?php endforeach; ?></select>
          <?php else: ?><input id="field_<?= e($key) ?>" type="<?= e($type) ?>" name="<?= e($key) ?>" value="<?= e($value) ?>" <?= !empty($field['required'])?'required':'' ?> <?= isset($field['step'])?'step="'.e($field['step']).'"':'' ?> <?= isset($field['min'])?'min="'.e($field['min']).'"':'' ?> <?= isset($field['max'])?'max="'.e($field['max']).'"':'' ?>><?php endif; ?>
          <?php if (!empty($field['help'])): ?><small><?= e($field['help']) ?></small><?php endif; ?>
        </div>
      <?php endforeach; ?>
      </div><div class="form-actions"><button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Create record' ?></button><?php if ($editing): ?><a class="btn btn-light" href="<?= e($module['active']) ?>">Cancel edit</a><?php endif; ?></div>
    </form>
  </section>
  <section class="table-panel"><div class="table-head"><div><h2>All <?= e($module['title']) ?></h2><p><?= count($rows) ?> records<?= $q!=='' ? ' matching “'.e($q).'”' : '' ?> · maximum 500 shown</p></div></div>
    <div class="table-tools"><form class="search-form" method="get" action="<?= e($module['active']) ?>"><input class="filter-control" name="q" value="<?= e($q) ?>" placeholder="Search <?= e(strtolower($module['title'])) ?>…"><button class="btn btn-primary" type="submit">Search</button><?php if ($q!==''): ?><a class="btn btn-light" href="<?= e($module['active']) ?>">Clear</a><?php endif; ?></form><a class="btn btn-light btn-sm" href="reports.php?dataset=<?= e($moduleKey) ?>&q=<?= urlencode($q) ?>">Export / reports</a></div>
    <div class="table-wrap"><table class="data-table"><thead><tr><?php foreach ($module['columns'] as $column): ?><th><?= e($column['label']) ?></th><?php endforeach; ?><th>Actions</th></tr></thead><tbody>
    <?php if (!$rows): ?><tr><td colspan="<?= count($module['columns'])+1 ?>"><div class="empty-state"><strong>No records found</strong>Add a record or change your search.</div></td></tr><?php else: foreach ($rows as $row): ?><tr><?php foreach ($module['columns'] as $column): $raw=$row[$column['key']] ?? null; ?><td class="<?= !empty($column['primary']) ? 'primary-cell' : '' ?>"><?= module_render_value($column, $raw, $sourceMaps) ?></td><?php endforeach; ?><td><div class="inline-actions"><a class="btn btn-light btn-sm" href="<?= e($module['active']) ?>?edit=<?= (int)$row['id'] ?>#record-form">Edit</a><?php if (is_admin()): ?><form method="post" action="<?= e($module['active']) ?>" data-confirm="Delete this record? This cannot be undone."><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$row['id'] ?>"><button class="btn btn-danger btn-sm" type="submit">Delete</button></form><?php endif; ?></div></td></tr><?php endforeach; endif; ?>
    </tbody></table></div><div class="table-foot">Changes are logged for audit purposes. Deleting linked records may be blocked to protect data integrity.</div>
  </section>
</div>
<?php require __DIR__ . '/layout_bottom.php'; ?>
