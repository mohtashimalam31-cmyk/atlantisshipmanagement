<?php
declare(strict_types=1);

$shipSource = ['table' => 'ships', 'value' => 'id', 'label' => 'vessel_name'];
$crewSource = ['table' => 'crew_members', 'value' => 'id', 'label' => 'full_name'];
$customerSource = ['table' => 'customers', 'value' => 'id', 'label' => 'company_name'];

return [
    'ships' => [
        'table' => 'ships', 'title' => 'Ships & Vessels', 'singular' => 'Vessel', 'description' => 'Maintain vessel particulars, availability and fleet notes.', 'active' => 'ships.php',
        'search_fields' => ['vessel_name','imo_number','vessel_type','flag','status'],
        'columns' => [
            ['key'=>'vessel_name','label'=>'Vessel','primary'=>true], ['key'=>'imo_number','label'=>'IMO Number'], ['key'=>'vessel_type','label'=>'Type','humanize'=>true], ['key'=>'flag','label'=>'Flag'], ['key'=>'capacity_tons','label'=>'Capacity (t)'], ['key'=>'status','label'=>'Status','status'=>true],
        ],
        'fields' => [
            ['key'=>'vessel_name','label'=>'Vessel name','type'=>'text','required'=>true],
            ['key'=>'imo_number','label'=>'IMO number','type'=>'text','required'=>false,'help'=>'Leave blank if the vessel has no IMO number recorded.'],
            ['key'=>'vessel_type','label'=>'Vessel type','type'=>'select','required'=>true,'options'=>['general_cargo'=>'General cargo','container'=>'Container','bulk_carrier'=>'Bulk carrier','tanker'=>'Tanker','ro_ro'=>'Ro-Ro','passenger'=>'Passenger','offshore'=>'Offshore support','other'=>'Other']],
            ['key'=>'flag','label'=>'Flag / registry','type'=>'text'],
            ['key'=>'capacity_tons','label'=>'Capacity (metric tonnes)','type'=>'number','step'=>'0.01','min'=>'0'],
            ['key'=>'year_built','label'=>'Year built','type'=>'number','step'=>'1','min'=>'1800','max'=>(string)((int)date('Y')+1)],
            ['key'=>'status','label'=>'Availability / status','type'=>'select','required'=>true,'options'=>['available'=>'Available','scheduled'=>'Scheduled','at_sea'=>'At sea','maintenance'=>'Maintenance','inactive'=>'Inactive']],
            ['key'=>'notes','label'=>'Operational notes','type'=>'textarea','full'=>true],
        ],
    ],
    'crew' => [
        'table' => 'crew_members', 'title' => 'Crew Members', 'singular' => 'Crew member', 'description' => 'Manage seafarer profiles, ranks, certificates and availability.', 'active' => 'crew.php',
        'search_fields' => ['full_name','rank_title','nationality','certificate_no','email','phone','status'],
        'columns' => [
            ['key'=>'full_name','label'=>'Crew member','primary'=>true], ['key'=>'rank_title','label'=>'Rank'], ['key'=>'nationality','label'=>'Nationality'], ['key'=>'certificate_expiry','label'=>'Certificate expiry'], ['key'=>'email','label'=>'Email'], ['key'=>'status','label'=>'Status','status'=>true],
        ],
        'fields' => [
            ['key'=>'full_name','label'=>'Full name','type'=>'text','required'=>true],
            ['key'=>'rank_title','label'=>'Rank / position','type'=>'text','required'=>true],
            ['key'=>'nationality','label'=>'Nationality','type'=>'text'],
            ['key'=>'certificate_no','label'=>'Certificate number','type'=>'text'],
            ['key'=>'certificate_expiry','label'=>'Certificate expiry','type'=>'date'],
            ['key'=>'phone','label'=>'Phone','type'=>'tel'],
            ['key'=>'email','label'=>'Email','type'=>'email'],
            ['key'=>'status','label'=>'Availability','type'=>'select','required'=>true,'options'=>['available'=>'Available','assigned'=>'Assigned','on_leave'=>'On leave','inactive'=>'Inactive']],
            ['key'=>'notes','label'=>'Notes','type'=>'textarea','full'=>true],
        ],
    ],
    'crew_assignments' => [
        'table'=>'crew_assignments','title'=>'Crew Assignments','singular'=>'Crew assignment','description'=>'Assign crew members to vessels and track rotation dates.', 'active'=>'crew_assignments.php',
        'search_fields'=>['role_onboard','status','notes'],
        'columns'=>[
            ['key'=>'crew_id','label'=>'Crew member','source'=>$crewSource,'primary'=>true], ['key'=>'ship_id','label'=>'Vessel','source'=>$shipSource], ['key'=>'role_onboard','label'=>'Onboard role'], ['key'=>'start_date','label'=>'Start date'], ['key'=>'end_date','label'=>'End date'], ['key'=>'status','label'=>'Status','status'=>true],
        ],
        'fields'=>[
            ['key'=>'crew_id','label'=>'Crew member','type'=>'source','source'=>$crewSource,'required'=>true],
            ['key'=>'ship_id','label'=>'Vessel','type'=>'source','source'=>$shipSource,'required'=>true],
            ['key'=>'role_onboard','label'=>'Role on board','type'=>'text','required'=>true],
            ['key'=>'start_date','label'=>'Assignment start','type'=>'date','required'=>true],
            ['key'=>'end_date','label'=>'Assignment end','type'=>'date'],
            ['key'=>'status','label'=>'Assignment status','type'=>'select','required'=>true,'options'=>['planned'=>'Planned','active'=>'Active','completed'=>'Completed','cancelled'=>'Cancelled']],
            ['key'=>'notes','label'=>'Notes','type'=>'textarea','full'=>true],
        ],
    ],
    'customers' => [
        'table'=>'customers','title'=>'Customers','singular'=>'Customer','description'=>'Maintain customer contacts and account notes.', 'active'=>'customers.php',
        'search_fields'=>['company_name','contact_name','email','phone','address'],
        'columns'=>[
            ['key'=>'company_name','label'=>'Company','primary'=>true], ['key'=>'contact_name','label'=>'Contact'], ['key'=>'email','label'=>'Email'], ['key'=>'phone','label'=>'Phone'], ['key'=>'created_at','label'=>'Added'],
        ],
        'fields'=>[
            ['key'=>'company_name','label'=>'Company / customer name','type'=>'text','required'=>true],
            ['key'=>'contact_name','label'=>'Primary contact','type'=>'text'],
            ['key'=>'email','label'=>'Email','type'=>'email'],
            ['key'=>'phone','label'=>'Phone','type'=>'tel'],
            ['key'=>'address','label'=>'Address','type'=>'textarea','full'=>true],
            ['key'=>'notes','label'=>'Account notes','type'=>'textarea','full'=>true],
        ],
    ],
    'bookings' => [
        'table'=>'bookings','title'=>'Bookings & Cargo','singular'=>'Booking','description'=>'Manage customer shipments, cargo details, route, vessel and delivery status.', 'active'=>'bookings.php',
        'search_fields'=>['booking_ref','origin_port','destination_port','cargo_description','status'],
        'columns'=>[
            ['key'=>'booking_ref','label'=>'Reference','primary'=>true], ['key'=>'customer_id','label'=>'Customer','source'=>$customerSource], ['key'=>'ship_id','label'=>'Vessel','source'=>$shipSource], ['key'=>'origin_port','label'=>'Origin'], ['key'=>'destination_port','label'=>'Destination'], ['key'=>'booking_date','label'=>'Booked'], ['key'=>'status','label'=>'Status','status'=>true],
        ],
        'fields'=>[
            ['key'=>'customer_id','label'=>'Customer','type'=>'source','source'=>$customerSource,'required'=>true],
            ['key'=>'ship_id','label'=>'Vessel (optional)','type'=>'source','source'=>$shipSource],
            ['key'=>'origin_port','label'=>'Origin port','type'=>'text','required'=>true],
            ['key'=>'destination_port','label'=>'Destination port','type'=>'text','required'=>true],
            ['key'=>'booking_date','label'=>'Booking date','type'=>'date','required'=>true,'default'=>date('Y-m-d')],
            ['key'=>'expected_arrival','label'=>'Expected arrival','type'=>'date'],
            ['key'=>'cargo_description','label'=>'Cargo description','type'=>'textarea','required'=>true,'full'=>true],
            ['key'=>'cargo_weight_tons','label'=>'Cargo weight (metric tonnes)','type'=>'number','step'=>'0.01','min'=>'0'],
            ['key'=>'status','label'=>'Shipment status','type'=>'select','required'=>true,'options'=>['pending'=>'Pending','confirmed'=>'Confirmed','in_transit'=>'In transit','delivered'=>'Delivered','cancelled'=>'Cancelled']],
        ],
    ],
    'maintenance' => [
        'table'=>'maintenance_records','title'=>'Vessel Maintenance','singular'=>'Maintenance record','description'=>'Track scheduled servicing, work in progress, completion dates and costs.', 'active'=>'maintenance.php',
        'search_fields'=>['maintenance_type','description','status'],
        'columns'=>[
            ['key'=>'ship_id','label'=>'Vessel','source'=>$shipSource,'primary'=>true], ['key'=>'maintenance_type','label'=>'Work type'], ['key'=>'scheduled_date','label'=>'Scheduled'], ['key'=>'completed_date','label'=>'Completed'], ['key'=>'cost','label'=>'Cost'], ['key'=>'status','label'=>'Status','status'=>true],
        ],
        'fields'=>[
            ['key'=>'ship_id','label'=>'Vessel','type'=>'source','source'=>$shipSource,'required'=>true],
            ['key'=>'maintenance_type','label'=>'Maintenance type','type'=>'text','required'=>true],
            ['key'=>'description','label'=>'Description / work scope','type'=>'textarea','required'=>true,'full'=>true],
            ['key'=>'scheduled_date','label'=>'Scheduled date','type'=>'date','required'=>true],
            ['key'=>'completed_date','label'=>'Completed date','type'=>'date'],
            ['key'=>'cost','label'=>'Cost (database currency)','type'=>'number','step'=>'0.01','min'=>'0'],
            ['key'=>'status','label'=>'Work status','type'=>'select','required'=>true,'options'=>['planned'=>'Planned','in_progress'=>'In progress','completed'=>'Completed','cancelled'=>'Cancelled']],
        ],
    ],
    'schedules' => [
        'table'=>'schedules','title'=>'Vessel Schedules','singular'=>'Schedule stop','description'=>'Record vessel port calls, arrival and departure timings.', 'active'=>'schedules.php',
        'search_fields'=>['port_name','status','notes'],
        'columns'=>[
            ['key'=>'ship_id','label'=>'Vessel','source'=>$shipSource,'primary'=>true], ['key'=>'port_name','label'=>'Port'], ['key'=>'arrival_datetime','label'=>'Arrival'], ['key'=>'departure_datetime','label'=>'Departure'], ['key'=>'status','label'=>'Status','status'=>true],
        ],
        'fields'=>[
            ['key'=>'ship_id','label'=>'Vessel','type'=>'source','source'=>$shipSource,'required'=>true],
            ['key'=>'port_name','label'=>'Port / terminal','type'=>'text','required'=>true],
            ['key'=>'arrival_datetime','label'=>'Arrival date & time','type'=>'datetime-local'],
            ['key'=>'departure_datetime','label'=>'Departure date & time','type'=>'datetime-local'],
            ['key'=>'status','label'=>'Schedule status','type'=>'select','required'=>true,'options'=>['planned'=>'Planned','arrived'=>'Arrived','departed'=>'Departed','delayed'=>'Delayed','cancelled'=>'Cancelled']],
            ['key'=>'notes','label'=>'Notes','type'=>'textarea','full'=>true],
        ],
    ],
];
